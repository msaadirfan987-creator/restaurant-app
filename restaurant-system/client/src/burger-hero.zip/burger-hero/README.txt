burger-hero
-----------
Hero.jsx                      -> apne src/components me copy karo
public/images/burger/*.png    -> apne project ke public/images/burger/ me copy karo
public/images/restaurant-bg.jpg -> public/images/ me copy karo

Use:
  import Hero from "./components/Hero";
  <Hero brand="Burger House" price="Rs. 1,290" onOrder={...} onMenu={...} />

Burger par click karne se animation dobara chalti hai.
Timing badalne ke liye Hero.jsx me ENTER_STAGGER / ASSEMBLE_STAGGER dekho.
