import { useEffect, useMemo, useState } from "react";

/**
 * Hero.jsx — Burger assemble hero (real photo ingredients)
 *
 * LEFT  : text (hamesha visible)
 * RIGHT : animation
 *
 * Flow:
 *  1. blur     -> background blur hota hai
 *  2. spread   -> ingredients (lettuce, tomato, cheese, patty, onion, pickle, buns, sauce)
 *                 apni photo wali jagah par float karte hue aate hain
 *  3. assemble -> sab ek ke baad ek burger ki tarah jud jate hain (sauce burger me mil jata hai)
 *  4. reveal   -> poora real burger fade-in hota hai aur halka sa float karta hai
 *
 * Images: /public/images/burger/*.png  aur  /public/images/restaurant-bg.jpg
 * Burger par click = animation dobara.
 */

const COLORS = {
  charcoal: "#1b1d1c",
  green: "#1f4a38",
  amber: "#d9a441",
  cream: "#f4ead5",
};

const IMG = "/images/burger";

// Stage = original photo ka size. Sab positions isi coordinate system me hain.
const STAGE_W = 1024;
const STAGE_H = 1536;

// Final burger (photo coordinates)
const FINAL = { x: 254, y: 223, w: 562, h: 743 };
const BURGER_CENTER = { x: FINAL.x + FINAL.w / 2, y: FINAL.y + FINAL.h / 2 };

/**
 * Har piece:
 *  nw, nh  : image ka natural size
 *  from    : spread state me center (photo me jahan ye ingredient float kar raha tha)
 *  rot     : spread state me rotation (deg)
 *  to      : burger me center + final w/h (assemble state)
 *  z, step : stacking order / assemble order (0 = sab se pehle, neeche)
 *  fly     : hidden state me kitna bahar se aata hai
 */
const PIECES = [
  { key: "bun-bottom", src: `${IMG}/bun-bottom.png`, nw: 485, nh: 109, from: { x: 725, y: 1285 }, rot: -22, to: { x: 501.5, y: 911.5, w: 485, h: 109 }, z: 2, step: 0, fly: { x: 220, y: 260 } },
  { key: "patty", src: `${IMG}/patty.png`, nw: 435, nh: 216, from: { x: 495, y: 1095 }, rot: -4, to: { x: 518, y: 800, w: 470, h: 135 }, z: 3, step: 1, fly: { x: 0, y: 320 } },
  { key: "cheese", src: `${IMG}/cheese.png`, nw: 296, nh: 286, from: { x: 148, y: 958 }, rot: 8, to: { x: 520, y: 782, w: 400, h: 120 }, z: 4, step: 2, fly: { x: -260, y: 120 } },
  { key: "pickle", src: `${IMG}/pickle.png`, nw: 262, nh: 175, from: { x: 936, y: 485 }, rot: 90, to: { x: 515, y: 716, w: 360, h: 84 }, z: 5, step: 3, fly: { x: 260, y: -120 } },
  { key: "onion", src: `${IMG}/onion.png`, nw: 252, nh: 205, from: { x: 921, y: 750 }, rot: 90, to: { x: 510, y: 660, w: 340, h: 96 }, z: 6, step: 4, fly: { x: 260, y: 40 } },
  { key: "tomato", src: `${IMG}/tomato.png`, nw: 259, nh: 266, from: { x: 130, y: 593 }, rot: -6, to: { x: 530, y: 606, w: 380, h: 120 }, z: 7, step: 5, fly: { x: -260, y: 0 } },
  { key: "lettuce-l", src: `${IMG}/lettuce-l.png`, nw: 308, nh: 332, from: { x: 154, y: 280 }, rot: -5, to: { x: 410, y: 545, w: 310, h: 190 }, z: 8, step: 6, fly: { x: -260, y: -200 } },
  { key: "lettuce-r", src: `${IMG}/lettuce-r.png`, nw: 323, nh: 312, from: { x: 862, y: 1025 }, rot: 6, to: { x: 660, y: 548, w: 310, h: 190 }, z: 8, step: 6, fly: { x: 260, y: 260 } },
  { key: "bun-top", src: `${IMG}/bun-top.png`, nw: 542, nh: 266, from: { x: 542, y: 207 }, rot: 0, to: { x: 542, y: 357, w: 542, h: 266 }, z: 9, step: 7, fly: { x: 0, y: -240 } },
];

// Sirf decoration: assemble par burger me "mil" jate hain (sauce)
const DECOR = [
  { key: "sauce-r", src: `${IMG}/sauce-r.png`, nw: 213, nh: 140, from: { x: 913, y: 171 }, rot: 6, fly: { x: 200, y: -200 } },
  { key: "sauce-l", src: `${IMG}/sauce-l.png`, nw: 244, nh: 193, from: { x: 153, y: 1220 }, rot: -6, fly: { x: -200, y: 220 } },
];

const ENTER_STAGGER = 110; // ms
const ENTER_DURATION = 1200;
const ASSEMBLE_STAGGER = 150;
const ASSEMBLE_DURATION = 1300;
const TIMELINE = {
  spread: 900,
  assemble: 900 + (PIECES.length + DECOR.length) * ENTER_STAGGER + ENTER_DURATION + 500,
};
TIMELINE.reveal = TIMELINE.assemble + 7 * ASSEMBLE_STAGGER + ASSEMBLE_DURATION + 150;

const EASE_OUT = "cubic-bezier(0.22, 1, 0.36, 1)";
const EASE_SETTLE = "cubic-bezier(0.34, 1.12, 0.64, 1)";

export default function Hero({
  backgroundSrc = "/images/restaurant-bg.jpg",
  finalBurgerSrc = `${IMG}/burger-final.png`,
  brand = "Burger House",
  title = "Fresh burger, grill se seedha aap tak",
  description = "Roz subah taaza bun, hand-pressed patty aur farm se aayi sabziyan. Har burger order par banta hai.",
  price = "Rs. 1,290",
  onOrder = () => {},
  onMenu = () => {},
}) {
  const [phase, setPhase] = useState("blur"); // blur | spread | assemble | reveal
  const [runId, setRunId] = useState(0);
  const [vp, setVp] = useState({ w: 1280, h: 800 });

  useEffect(() => {
    const update = () => setVp({ w: window.innerWidth, h: window.innerHeight });
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  useEffect(() => {
    setPhase("blur");
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setPhase("reveal");
      return;
    }
    const t = [
      setTimeout(() => setPhase("spread"), TIMELINE.spread),
      setTimeout(() => setPhase("assemble"), TIMELINE.assemble),
      setTimeout(() => setPhase("reveal"), TIMELINE.reveal),
    ];
    return () => t.forEach(clearTimeout);
  }, [runId]);

  const isMobile = vp.w < 860;
  const assembled = phase === "assemble" || phase === "reveal";
  const revealed = phase === "reveal";

  // Stage scales: spread me poori photo fit, assemble me burger par zoom
  const { s0, s1 } = useMemo(() => {
    const pad = Math.min(72, Math.max(24, vp.w * 0.05));
    const colW = isMobile ? vp.w - 48 : (Math.min(vp.w, 1320) - pad * 2 - 24) / 2;
    const colH = isMobile ? vp.h * 0.52 : vp.h;
    return {
      s0: Math.min((colH * 0.92) / STAGE_H, colW / STAGE_W),
      s1: Math.min(1.15, (colH * 0.82) / FINAL.h, (colW * 0.98) / FINAL.w),
    };
  }, [vp, isMobile]);

  // Stage ko is tarah move karo ke burger column ke center me aaye
  const dx = BURGER_CENTER.x - STAGE_W / 2;
  const dy = BURGER_CENTER.y - STAGE_H / 2;
  const stageTransform = assembled
    ? `translate(${-dx * s1}px, ${-dy * s1}px) scale(${s1})`
    : `translate(0px, 0px) scale(${s0})`;

  const pieceStyle = (p, i) => {
    const base = { left: p.to.x - p.nw / 2, top: p.to.y - p.nh / 2, width: p.nw, height: p.nh, zIndex: p.z };
    const sx = p.to.w / p.nw;
    const sy = p.to.h / p.nh;
    const move = (cx, cy, rot, scx, scy) =>
      `translate(${cx - p.to.x}px, ${cy - p.to.y}px) rotate(${rot}deg) scale(${scx}, ${scy})`;

    if (phase === "blur") {
      return {
        ...base,
        transform: move(p.from.x + p.fly.x, p.from.y + p.fly.y, p.rot * 1.8, 0.85, 0.85),
        opacity: 0,
        transition: "none",
      };
    }
    if (phase === "spread") {
      const d = i * ENTER_STAGGER;
      return {
        ...base,
        transform: move(p.from.x, p.from.y, p.rot, 1, 1),
        opacity: 1,
        transition: `transform ${ENTER_DURATION}ms ${EASE_OUT} ${d}ms, opacity 700ms ease ${d}ms`,
      };
    }
    // assemble / reveal
    const d = phase === "assemble" ? p.step * ASSEMBLE_STAGGER : 0;
    return {
      ...base,
      transform: move(p.to.x, p.to.y, 0, sx, sy),
      opacity: revealed ? 0 : 1,
      transition: revealed
        ? "opacity 700ms ease 200ms"
        : `transform ${ASSEMBLE_DURATION}ms ${EASE_SETTLE} ${d}ms`,
    };
  };

  const decorStyle = (p, i) => {
    const base = { left: p.from.x - p.nw / 2, top: p.from.y - p.nh / 2, width: p.nw, height: p.nh, zIndex: 1 };
    const tr = (x, y, rot, s) => `translate(${x - p.from.x}px, ${y - p.from.y}px) rotate(${rot}deg) scale(${s})`;
    const idx = PIECES.length + i;
    if (phase === "blur") {
      return { ...base, transform: tr(p.from.x + p.fly.x, p.from.y + p.fly.y, p.rot * 2, 0.8), opacity: 0, transition: "none" };
    }
    if (phase === "spread") {
      const d = idx * ENTER_STAGGER;
      return {
        ...base,
        transform: tr(p.from.x, p.from.y, p.rot, 1),
        opacity: 1,
        transition: `transform ${ENTER_DURATION}ms ${EASE_OUT} ${d}ms, opacity 700ms ease ${d}ms`,
      };
    }
    return {
      ...base,
      transform: tr(BURGER_CENTER.x, 790, 0, 0.18),
      opacity: 0,
      transition: `transform 1100ms cubic-bezier(0.65, 0, 0.35, 1) ${i * 120 + 500}ms, opacity 500ms ease ${i * 120 + 900}ms`,
    };
  };

  return (
    <section className="bh-hero" aria-label={brand}>
      <style>{css}</style>

      <div
        className="bh-bg"
        style={{ backgroundImage: `url(${backgroundSrc})`, transform: phase === "blur" ? "scale(1.0)" : "scale(1.06)" }}
        aria-hidden="true"
      />
      <div
        className="bh-bg-blur"
        style={{
          backdropFilter: `blur(${phase === "blur" ? 0 : 18}px)`,
          WebkitBackdropFilter: `blur(${phase === "blur" ? 0 : 18}px)`,
          backgroundColor: phase === "blur" ? "rgba(27,29,28,0.1)" : "rgba(27,29,28,0.6)",
        }}
        aria-hidden="true"
      />

      <div className="bh-grid">
        {/* LEFT: text */}
        <div className="bh-content">
          <p className="bh-brand">{brand}</p>
          <h1 className="bh-title">{title}</h1>
          <p className="bh-desc">{description}</p>
          <div className="bh-row">
            <span className="bh-price">{price}</span>
            <button type="button" className="bh-btn bh-btn--primary" onClick={onOrder}>
              Order now
            </button>
            <button type="button" className="bh-btn bh-btn--ghost" onClick={onMenu}>
              View menu
            </button>
          </div>
        </div>

        {/* RIGHT: animation */}
        <div className="bh-visual" onClick={() => setRunId((r) => r + 1)} title="Dobara chalane ke liye click karo">
          <div
            className="bh-stage"
            style={{
              width: STAGE_W,
              height: STAGE_H,
              marginLeft: -STAGE_W / 2,
              marginTop: -STAGE_H / 2,
              transform: stageTransform,
              transition: assembled
                ? `transform 2200ms cubic-bezier(0.65, 0, 0.35, 1)`
                : phase === "blur"
                ? "none"
                : "transform 600ms ease",
            }}
            role="img"
            aria-label="Burger ke ingredients jud kar burger bante hue"
          >
            <div className={`bh-float ${revealed ? "is-on" : ""}`}>
              {DECOR.map((p, i) => (
                <img key={p.key} src={p.src} alt="" draggable={false} className="bh-piece" style={decorStyle(p, i)} />
              ))}
              {PIECES.map((p, i) => (
                <img key={p.key} src={p.src} alt="" draggable={false} className="bh-piece" style={pieceStyle(p, i)} />
              ))}
              <img
                src={finalBurgerSrc}
                alt="Taaza grilled cheese burger"
                draggable={false}
                className="bh-final"
                style={{
                  left: FINAL.x,
                  top: FINAL.y,
                  width: FINAL.w,
                  height: FINAL.h,
                  opacity: revealed ? 1 : 0,
                  transform: revealed ? "scale(1)" : "scale(0.985)",
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

const css = `
.bh-hero {
  --charcoal: ${COLORS.charcoal};
  --green: ${COLORS.green};
  --amber: ${COLORS.amber};
  --cream: ${COLORS.cream};
  position: relative;
  min-height: 100vh;
  min-height: 100svh;
  overflow: hidden;
  background: var(--charcoal);
  color: var(--cream);
  font-family: "Inter", "Segoe UI", system-ui, sans-serif;
}
.bh-bg {
  position: absolute;
  inset: 0;
  background-size: cover;
  background-position: center;
  background-color: var(--charcoal);
  transition: transform 2400ms ease;
}
.bh-bg-blur {
  position: absolute;
  inset: 0;
  transition: backdrop-filter 1200ms ease, -webkit-backdrop-filter 1200ms ease, background-color 1200ms ease;
}

.bh-grid {
  position: relative;
  z-index: 2;
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: center;
  min-height: 100vh;
  min-height: 100svh;
  max-width: 1320px;
  margin: 0 auto;
  padding: 0 clamp(24px, 5vw, 72px);
  gap: 24px;
}

/* LEFT */
.bh-content {
  display: flex;
  flex-direction: column;
  gap: 20px;
  animation: bh-text-in 1000ms ${EASE_OUT} 500ms both;
}
@keyframes bh-text-in {
  from { opacity: 0; transform: translateX(-28px); }
  to { opacity: 1; transform: translateX(0); }
}
.bh-brand { margin: 0; font-size: 15px; font-weight: 600; letter-spacing: 0.04em; color: var(--amber); }
.bh-title {
  margin: 0;
  font-family: "Playfair Display", Georgia, "Times New Roman", serif;
  font-size: clamp(34px, 4.6vw, 64px);
  line-height: 1.08;
  font-weight: 700;
}
.bh-desc { margin: 0; max-width: 46ch; font-size: 17px; line-height: 1.65; color: rgba(244, 234, 213, 0.84); }
.bh-row { display: flex; flex-wrap: wrap; align-items: center; gap: 14px; margin-top: 8px; }
.bh-price { margin-right: 8px; font-size: 28px; font-weight: 700; color: var(--amber); }
.bh-btn {
  cursor: pointer;
  padding: 14px 26px;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 600;
  font-family: inherit;
  transition: background-color 200ms ease, border-color 200ms ease;
}
.bh-btn:focus-visible { outline: 3px solid var(--cream); outline-offset: 3px; }
.bh-btn--primary { border: 2px solid var(--amber); background: var(--amber); color: var(--charcoal); }
.bh-btn--primary:hover { background: #e6b658; border-color: #e6b658; }
.bh-btn--ghost { border: 2px solid rgba(244, 234, 213, 0.5); background: transparent; color: var(--cream); }
.bh-btn--ghost:hover { border-color: var(--cream); background: rgba(244, 234, 213, 0.08); }

/* RIGHT */
.bh-visual { position: relative; height: 100vh; height: 100svh; cursor: pointer; }
.bh-stage { position: absolute; left: 50%; top: 50%; transform-origin: center; will-change: transform; }
.bh-float { position: absolute; inset: 0; }
.bh-float.is-on { animation: bh-float 4.5s ease-in-out infinite; }
@keyframes bh-float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
}
.bh-piece {
  position: absolute;
  max-width: none;
  user-select: none;
  will-change: transform, opacity;
  filter: drop-shadow(0 18px 20px rgba(0, 0, 0, 0.45));
}
.bh-final {
  position: absolute;
  max-width: none;
  user-select: none;
  transition: opacity 800ms ease 200ms, transform 1000ms ${EASE_OUT} 200ms;
  filter: drop-shadow(0 26px 30px rgba(0, 0, 0, 0.5));
}

/* Mobile: animation upar, text neeche */
@media (max-width: 859px) {
  .bh-grid { grid-template-columns: 1fr; grid-template-rows: 52svh auto; align-items: start; padding-bottom: 40px; }
  .bh-visual { order: -1; height: 52svh; }
  .bh-title { font-size: clamp(28px, 8vw, 38px); }
  .bh-desc { font-size: 15px; }
}

@media (prefers-reduced-motion: reduce) {
  .bh-content { animation: none; }
  .bh-float.is-on { animation: none; }
  .bh-piece, .bh-final, .bh-bg-blur, .bh-stage, .bh-bg { transition: none !important; }
}
`;
