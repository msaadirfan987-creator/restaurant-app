# Admin Login + Animated Dashboard

## Kya kya hai
```
frontend/   AdminApp.jsx  AdminLogin.jsx  AdminLayout.jsx  AdminDashboard.jsx  useAdminSession.js  adminApi.js
backend/    config/authConfig.js  models/User.js  middleware/auth.js  routes/adminAuth.js
            routes/signup.example.js  scripts/seedAdmin.js  server.example.js
            tests/admin.auth.test.js  .env.example  .gitignore.snippet
```

## Kya TEST hua aur kya NAHI (sach)
- VERIFIED (Chromium me, mock API ke saath): login validation, loading animation, wrong-password error,
  show/hide password, login -> /admin/dashboard, "Welcome, Admin", logout -> /admin/login,
  logout ke baad dashboard par redirect, already-logged-in admin ka login page se dashboard par jana,
  server 500 par error state + retry, mobile layout aur drawer.
- NOT RUN: backend code aur Jest tests. Us environment me Express, MongoDB, bcrypt, jest install nahi ho sakte the.
  Backend ki sirf syntax check hui hai (`node --check`). Pehli baar chalane par khud verify karo.
- Real backend ke saath end-to-end (cookie set hona, 403 for customer) abhi verify nahi hua.

## Backend setup
1. Packages: `npm i bcryptjs jsonwebtoken cookie-parser express-rate-limit helmet dotenv`  (mongoose/express aapke paas hain)
   Tests ke liye: `npm i -D jest supertest`
2. `.env.example` ko `.env` me copy karo, `JWT_SECRET` generate karo
   (`node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`).
3. `.gitignore` me `.gitignore.snippet` ki lines add karo (`.env` kabhi commit mat karo).
4. `server.example.js` ke hisse apne asli server me jodo (`/api/admin` routes + admin guard + error handler).
5. Apne User model me `role`, `tokenVersion`, `isActive`, `passwordHash` fields ensure karo (models/User.js dekho).
6. Pehla admin: `.env` me ADMIN_EMAIL aur ADMIN_PASSWORD (12+ chars) daalo ->
   `node scripts/seedAdmin.js` -> phir `.env` se ADMIN_PASSWORD hata do.
7. Signup route me role kabhi body se mat lo (routes/signup.example.js).

## Frontend setup
- `frontend/*` ko `src/admin/` me copy karo.
- `/admin/*` par `<AdminApp />` render karo (ya sirf AdminLogin/AdminDashboard ko react-router me lagao).
- Dev me API proxy zaroori hai (Vite: `server.proxy["/api"]`, CRA: `"proxy"` in package.json) taake cookie same-origin rahe.
- Framer Motion use nahi kiya: saari animations CSS se hain (kam dependency, reduced-motion support).
- Design aapki site ki theme ke mutabiq hai (flat dark, amber/cream/green). Gradients jaan bujh kar nahi rakhe.

## Security ka khulasa
Password bcrypt (cost 12), token httpOnly cookie, Secure in production, SameSite=lax, role har request par DB se check,
logout par tokenVersion badhta hai (purane tokens server par bhi invalid), login par rate limit, generic error messages,
error handler stack trace nahi bhejta, koi secret frontend me nahi.
