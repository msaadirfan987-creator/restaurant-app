import { useEffect, useState } from "react";

/**
 * AdminLayout.jsx — sidebar + top bar + animated page area.
 * Sidebar me sirf wahi hai jo zaroori hai: Dashboard link aur Logout.
 * Naye admin pages ke liye `nav` prop me items add karo aur children badlo.
 *
 * <AdminLayout user={user} pageKey="dashboard" onLogout={...}>...</AdminLayout>
 */

const COLORS = { bg: "#151a17", surface: "#1b211e", green: "#1f4a38", amber: "#d9a441", cream: "#f4ead5" };

export default function AdminLayout({
  user,
  pageKey = "dashboard",
  title = "Dashboard",
  nav = [{ key: "dashboard", label: "Dashboard" }],
  onLogout,
  children,
  brand = "Burger House",
  mark = "BH",
}) {
  const [open, setOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const logout = async () => {
    if (loggingOut) return;
    setLoggingOut(true);
    try {
      await onLogout();
    } finally {
      setLoggingOut(false);
    }
  };

  const initial = (user?.name || user?.email || "A").trim().charAt(0).toUpperCase();

  return (
    <div className="ad-shell">
      <style>{css}</style>

      <aside className={`ad-side ${open ? "is-open" : ""}`} aria-label="Admin navigation">
        <div className="ad-side-top">
          <span className="ad-mark">{mark}</span>
          <span className="ad-brand">{brand}</span>
        </div>
        <nav className="ad-nav">
          {nav.map((n, i) => (
            <a key={n.key} href={n.href || "#"} className={`ad-link ${n.key === pageKey ? "is-active" : ""}`} style={{ "--i": i }}
              aria-current={n.key === pageKey ? "page" : undefined}
              onClick={(e) => { if (!n.href) e.preventDefault(); setOpen(false); }}>
              {n.label}
            </a>
          ))}
        </nav>
        <button type="button" className="ad-btn ad-btn--ghost ad-side-logout" onClick={logout} disabled={loggingOut}>
          {loggingOut ? "Logging out" : "Logout"}
        </button>
      </aside>
      {open && <button type="button" className="ad-scrim" aria-label="Close menu" onClick={() => setOpen(false)} />}

      <div className="ad-main">
        <header className="ad-top">
          <div className="ad-top-left">
            <button type="button" className="ad-btn ad-btn--ghost ad-menu" onClick={() => setOpen((o) => !o)} aria-expanded={open}>Menu</button>
            <span className="ad-page-title">{title}</span>
          </div>
          <div className="ad-top-right">
            <div className="ad-profile">
              <span className="ad-avatar" aria-hidden="true">{initial}</span>
              <span className="ad-profile-text">
                <span className="ad-profile-name">{user?.name || "Admin"}</span>
                <span className="ad-profile-role">Administrator</span>
              </span>
            </div>
            <button type="button" className="ad-btn ad-btn--solid ad-top-logout" onClick={logout} disabled={loggingOut}>
              {loggingOut ? "Logging out" : "Logout"}
            </button>
          </div>
        </header>

        {/* key badalne par page transition chalti hai */}
        <main key={pageKey} className="ad-content">{children}</main>
      </div>
    </div>
  );
}

const EASE = "cubic-bezier(0.22, 1, 0.36, 1)";
const css = `
.ad-shell { --bg:${COLORS.bg}; --surface:${COLORS.surface}; --green:${COLORS.green}; --amber:${COLORS.amber}; --cream:${COLORS.cream};
  display: flex; min-height: 100vh; min-height: 100svh; background: var(--bg); color: var(--cream);
  font-family: "Inter", "Segoe UI", system-ui, sans-serif; }
.ad-shell *, .ad-shell *::before, .ad-shell *::after { box-sizing: border-box; }

.ad-side { position: sticky; top: 0; align-self: flex-start; z-index: 30; display: flex; flex-direction: column; gap: 28px; width: 250px; height: 100vh; height: 100svh; padding: 24px 18px;
  background: var(--surface); border-right: 1px solid rgba(244, 234, 213, 0.08); animation: ad-side-in 800ms ${EASE} both; }
@keyframes ad-side-in { from { opacity: 0; transform: translateX(-28px); } to { opacity: 1; transform: none; } }
.ad-side-top { display: flex; align-items: center; gap: 12px; padding: 0 6px; }
.ad-mark { width: 40px; height: 40px; border-radius: 8px; background: var(--amber); color: var(--bg); display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 16px; }
.ad-brand { font-family: "Playfair Display", Georgia, serif; font-size: 20px; font-weight: 700; }
.ad-nav { display: flex; flex-direction: column; gap: 6px; flex: 1; }
.ad-link { position: relative; display: block; padding: 12px 14px; border-radius: 8px; color: rgba(244, 234, 213, 0.75); font-size: 15px; font-weight: 600; text-decoration: none;
  opacity: 0; animation: ad-fade-up 600ms ${EASE} both; animation-delay: calc(var(--i) * 90ms + 350ms); transition: background-color 220ms ease, color 220ms ease; }
.ad-link::before { content: ""; position: absolute; left: 0; top: 10px; bottom: 10px; width: 3px; border-radius: 2px; background: var(--amber); transform: scaleY(0); transition: transform 350ms ${EASE}; }
.ad-link:hover { background: rgba(244, 234, 213, 0.06); color: var(--cream); }
.ad-link.is-active { background: rgba(217, 164, 65, 0.12); color: var(--amber); }
.ad-link.is-active::before { transform: scaleY(1); }
.ad-link:focus-visible, .ad-btn:focus-visible, .ad-scrim:focus-visible { outline: 3px solid var(--cream); outline-offset: 2px; }
@keyframes ad-fade-up { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: none; } }

.ad-btn { cursor: pointer; padding: 10px 20px; border-radius: 8px; font-family: inherit; font-size: 14px; font-weight: 700; transition: background-color 220ms ease, border-color 220ms ease, color 220ms ease, transform 160ms ease; }
.ad-btn:active:not(:disabled) { transform: scale(0.97); }
.ad-btn:disabled { cursor: progress; opacity: 0.7; }
.ad-btn--solid { border: 2px solid var(--amber); background: var(--amber); color: var(--bg); }
.ad-btn--solid:hover:not(:disabled) { background: #e6b658; border-color: #e6b658; }
.ad-btn--ghost { border: 2px solid rgba(244, 234, 213, 0.35); background: transparent; color: var(--cream); }
.ad-btn--ghost:hover:not(:disabled) { border-color: var(--amber); color: var(--amber); }
.ad-side-logout { display: none; }

.ad-main { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.ad-top { position: sticky; top: 0; z-index: 20; display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 14px clamp(16px, 3vw, 36px);
  background: var(--bg); border-bottom: 1px solid rgba(244, 234, 213, 0.08); animation: ad-fade-down 700ms ${EASE} 200ms both; }
@keyframes ad-fade-down { from { opacity: 0; transform: translateY(-14px); } to { opacity: 1; transform: none; } }
.ad-top-left, .ad-top-right { display: flex; align-items: center; gap: 14px; }
.ad-menu { display: none; padding: 8px 16px; }
.ad-page-title { font-size: 15px; font-weight: 600; color: rgba(244, 234, 213, 0.7); }
.ad-profile { display: flex; align-items: center; gap: 10px; }
.ad-avatar { width: 38px; height: 38px; border-radius: 50%; background: var(--green); color: var(--cream); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 15px; }
.ad-profile-text { display: flex; flex-direction: column; line-height: 1.25; }
.ad-profile-name { font-size: 14px; font-weight: 700; }
.ad-profile-role { font-size: 12px; color: rgba(244, 234, 213, 0.6); }

.ad-content { position: relative; flex: 1; overflow: hidden; padding: clamp(24px, 4vw, 56px); animation: ad-page 700ms ${EASE} both; }
@keyframes ad-page { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: none; } }

.ad-scrim { position: fixed; inset: 0; z-index: 25; border: 0; background: rgba(0, 0, 0, 0.55); animation: ad-scrim 300ms ease both; }
@keyframes ad-scrim { from { opacity: 0; } to { opacity: 1; } }

@media (max-width: 860px) {
  .ad-side { position: fixed; left: 0; top: 0; bottom: 0; transform: translateX(-105%); animation: none; transition: transform 450ms ${EASE}; }
  .ad-side.is-open { transform: none; }
  .ad-side-logout { display: block; }
  .ad-menu { display: inline-block; }
  .ad-top-logout, .ad-profile-text { display: none; }
}
@media (prefers-reduced-motion: reduce) {
  .ad-shell *, .ad-shell *::before, .ad-shell *::after { animation: none !important; transition: none !important; }
  .ad-link { opacity: 1; }
}
`;
