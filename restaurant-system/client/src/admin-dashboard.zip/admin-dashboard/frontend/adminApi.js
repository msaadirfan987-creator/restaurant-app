// adminApi.js — admin endpoints ke liye chhota fetch helper.
// Token JS me kabhi store nahi hota: server httpOnly cookie set karta hai, browser khud bhejta hai.
const BASE = "/api/admin";

async function request(path, { method = "GET", body } = {}) {
  let res;
  try {
    res = await fetch(`${BASE}${path}`, {
      method,
      credentials: "include",
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    const err = new Error("Could not reach the server. Check your connection and try again.");
    err.network = true;
    throw err;
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.message || "Something went wrong. Please try again.");
    err.status = res.status;
    throw err;
  }
  return data;
}

export const adminApi = {
  login: (email, password) => request("/login", { method: "POST", body: { email, password } }),
  logout: () => request("/logout", { method: "POST" }),
  me: () => request("/me"),
};
