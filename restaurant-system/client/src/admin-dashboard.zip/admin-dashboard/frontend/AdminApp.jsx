import { useCallback, useEffect, useState } from "react";
import { adminApi } from "./adminApi";
import AdminLogin from "./AdminLogin";
import AdminDashboard from "./AdminDashboard";

/**
 * AdminApp.jsx — /admin/* routes (dependency-free, History API).
 *   /admin/login      -> AdminLogin   (agar session pehle se valid ho to dashboard par bhej deta hai)
 *   /admin/dashboard  -> AdminDashboard (server session verify; nahi to login par redirect)
 *
 * react-router use karte ho to sirf AdminLogin aur AdminDashboard ko apne <Route> me lagao
 * aur navigate() ko useNavigate() se replace karo.
 *
 * Mount: agar window.location.pathname "/admin" se shuru ho to <AdminApp /> render karo.
 */

function usePath() {
  const [path, setPath] = useState(() => window.location.pathname);
  useEffect(() => {
    const on = () => setPath(window.location.pathname);
    window.addEventListener("popstate", on);
    return () => window.removeEventListener("popstate", on);
  }, []);
  const navigate = useCallback((to, { replace = true } = {}) => {
    window.history[replace ? "replaceState" : "pushState"]({}, "", to);
    setPath(to);
  }, []);
  return [path, navigate];
}

function LoginRoute({ navigate }) {
  // Pehle se logged-in admin ko login form dikhane ki zaroorat nahi
  const [checked, setChecked] = useState(false);
  useEffect(() => {
    let alive = true;
    adminApi.me().then(() => alive && navigate("/admin/dashboard")).catch(() => alive && setChecked(true));
    return () => { alive = false; };
  }, [navigate]);
  if (!checked) return null;
  return <AdminLogin onSuccess={() => navigate("/admin/dashboard")} />;
}

export default function AdminApp() {
  const [path, navigate] = usePath();
  const toLogin = useCallback(() => navigate("/admin/login"), [navigate]);

  useEffect(() => {
    if (!["/admin/login", "/admin/dashboard"].includes(path)) navigate("/admin/dashboard");
  }, [path, navigate]);

  if (path === "/admin/login") return <LoginRoute navigate={navigate} />;
  if (path === "/admin/dashboard") return <AdminDashboard onUnauthorized={toLogin} onLoggedOut={toLogin} />;
  return null;
}
