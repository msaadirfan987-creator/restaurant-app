// config/authConfig.js — auth ki saari settings ek jagah. Secrets sirf environment se aate hain.
const isProd = process.env.NODE_ENV === "production";

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  // Server start hi nahi hoga agar secret kamzor/missing ho. Koi default secret nahi.
  throw new Error("JWT_SECRET must be set in the environment and be at least 32 characters long.");
}

const COOKIE_NAME = "admin_session";
const TOKEN_TTL = process.env.JWT_EXPIRES_IN || "8h";
const TOKEN_TTL_MS = 8 * 60 * 60 * 1000; // cookie maxAge (TOKEN_TTL ke barabar rakho)

// HttpOnly: JS token nahi padh sakti. Secure: production me sirf HTTPS. SameSite: CSRF se bachav.
const cookieOptions = {
  httpOnly: true,
  secure: isProd,
  sameSite: process.env.COOKIE_SAMESITE || "lax", // frontend alag domain par ho to "none" (aur secure true) chahiye
  path: "/",
  maxAge: TOKEN_TTL_MS,
};
const clearCookieOptions = { ...cookieOptions };
delete clearCookieOptions.maxAge;

module.exports = { JWT_SECRET, COOKIE_NAME, TOKEN_TTL, cookieOptions, clearCookieOptions };
