// server.example.js — apne asli server file me sirf ye hisse jod do (naya server mat banao).
require("dotenv").config();
const express = require("express");
const cookieParser = require("cookie-parser");
const helmet = require("helmet"); // optional lekin recommended
const mongoose = require("mongoose");

const { authenticate, requireRole } = require("./middleware/auth");
const adminAuthRoutes = require("./routes/adminAuth");

const app = express();
app.set("trust proxy", 1); // reverse proxy (Nginx, Render, Heroku) ke peeche ho to
app.use(helmet());
app.use(express.json({ limit: "10kb" }));
app.use(cookieParser());

// 1) Login / logout / me
app.use("/api/admin", adminAuthRoutes);

// 2) Baaki SAARE admin routes yahan se guzarte hain: login zaroori + role === "admin" zaroori.
//    Customer ko 403 milega, bina login wale ko 401.
const adminRouter = express.Router();
// adminRouter.get("/orders", ...);  // future admin APIs yahan lagao
app.use("/api/admin", authenticate, requireRole("admin"), adminRouter);

// 3) Error handler: stack trace frontend ko kabhi nahi jata.
app.use((err, req, res, next) => {
  console.error(err); // sirf server log me
  res.status(500).json({ message: "Something went wrong." });
});

mongoose.connect(process.env.MONGODB_URI).then(() => app.listen(process.env.PORT || 5000));

module.exports = app;
