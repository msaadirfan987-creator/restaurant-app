// middleware/auth.js — authenticate (kaun hai?) + requireRole (kya karne ki ijazat hai?)
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const { JWT_SECRET, COOKIE_NAME } = require("../config/authConfig");

async function authenticate(req, res, next) {
  try {
    const token = req.cookies && req.cookies[COOKIE_NAME];
    if (!token) return res.status(401).json({ message: "Authentication required." });

    let payload;
    try {
      payload = jwt.verify(token, JWT_SECRET, { algorithms: ["HS256"] });
    } catch {
      return res.status(401).json({ message: "Your session has expired. Please sign in again." });
    }

    // Har request par database se user check hota hai: role badal gaya, user disable hua,
    // ya logout ho gaya (tokenVersion badla) to purana token fauran bekaar.
    const user = await User.findById(payload.sub);
    if (!user || !user.isActive || user.tokenVersion !== payload.tv) {
      return res.status(401).json({ message: "Your session is no longer valid. Please sign in again." });
    }

    req.user = { id: String(user._id), name: user.name, email: user.email, role: user.role };
    next();
  } catch (err) {
    next(err);
  }
}

const requireRole = (...roles) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ message: "Authentication required." });
  if (!roles.includes(req.user.role)) return res.status(403).json({ message: "Forbidden." });
  next();
};

module.exports = { authenticate, requireRole };
