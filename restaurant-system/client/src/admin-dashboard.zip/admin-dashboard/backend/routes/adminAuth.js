// routes/adminAuth.js — /api/admin/login, /logout, /me
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const rateLimit = require("express-rate-limit");
const User = require("../models/User");
const { authenticate, requireRole } = require("../middleware/auth");
const { JWT_SECRET, COOKIE_NAME, TOKEN_TTL, cookieOptions, clearCookieOptions } = require("../config/authConfig");

const router = express.Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: "Too many login attempts. Please try again later." },
});

// Jab email exist nahi karta tab bhi bcrypt chalta hai -> response time se email guess nahi hota.
const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", 12);

router.post("/login", loginLimiter, async (req, res, next) => {
  try {
    const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (!email || !password) return res.status(400).json({ message: "Email and password are required." });

    const user = await User.findOne({ email }).select("+passwordHash");
    const passwordOk = await bcrypt.compare(password, user ? user.passwordHash : DUMMY_HASH);

    // Ek hi generic message: galat email, galat password, non-admin ya disabled, sab ke liye.
    if (!user || !passwordOk || !user.isActive || user.role !== "admin") {
      return res.status(401).json({ message: "Invalid email or password." });
    }

    const token = jwt.sign({ sub: String(user._id), role: user.role, tv: user.tokenVersion }, JWT_SECRET, {
      algorithm: "HS256",
      expiresIn: TOKEN_TTL,
    });
    res.cookie(COOKIE_NAME, token, cookieOptions);
    res.json({ user: { name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
});

// Logout hamesha cookie clear karta hai. Token valid ho to tokenVersion badha kar
// us token (aur is user ke baaki sab purane tokens) ko server par bhi invalid kar deta hai.
router.post("/logout", async (req, res, next) => {
  try {
    const token = req.cookies && req.cookies[COOKIE_NAME];
    if (token) {
      try {
        const payload = jwt.verify(token, JWT_SECRET, { algorithms: ["HS256"] });
        await User.updateOne({ _id: payload.sub }, { $inc: { tokenVersion: 1 } });
      } catch {
        /* token pehle se invalid/expired: sirf cookie clear karna kaafi hai */
      }
    }
    res.clearCookie(COOKIE_NAME, clearCookieOptions);
    res.json({ message: "Logged out." });
  } catch (err) {
    next(err);
  }
});

// Frontend dashboard khulne par isse session verify karta hai.
router.get("/me", authenticate, requireRole("admin"), (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
