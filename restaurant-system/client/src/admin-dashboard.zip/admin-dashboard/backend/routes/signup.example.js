// routes/signup.example.js — customer signup. ROLE KABHI request body se mat lo.
const bcrypt = require("bcryptjs");
const User = require("../models/User");

module.exports = async function signup(req, res, next) {
  try {
    const { name, email, phone, password } = req.body || {};   // <- "role" ko jaan bujh kar destructure nahi kiya
    if (typeof password !== "string" || password.length < 8) {
      return res.status(400).json({ message: "Password must be at least 8 characters." });
    }
    const user = await User.create({
      name,
      email,
      phone,
      passwordHash: await bcrypt.hash(password, 12),
      role: "customer",                                          // <- hamesha customer, hard-coded
    });
    res.status(201).json({ user: { name: user.name, role: user.role } });
  } catch (err) {
    next(err);
  }
};
