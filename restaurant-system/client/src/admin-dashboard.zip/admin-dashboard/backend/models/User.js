// models/User.js
// Agar aapke project me pehle se User model hai to ISE USE MAT KARO: apne model me ye fields add karo:
//   role (enum), tokenVersion (Number, default 0), isActive (Boolean, default true), passwordHash (select: false)
const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true, select: false }, // kabhi query me default se nahi aata
    role: { type: String, enum: ["admin", "cashier", "waiter", "kitchen", "customer"], default: "customer" },
    tokenVersion: { type: Number, default: 0 }, // logout par badhta hai -> purane tokens server par invalid
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.models.User || mongoose.model("User", userSchema);
