/**
 * tests/admin.auth.test.js — Jest + Supertest
 * Run: npm i -D jest supertest   ->   npx jest
 * Database ki jagah in-memory fake User model use hota hai (MongoDB ki zaroorat nahi).
 *
 * NOTE: ye tests us environment me likhe gaye jahan jest/supertest install nahi ho sakte the,
 * is liye inhe abhi tak chalaya NAHI gaya. Pehli baar chalane par chhoti adjustments lag sakti hain.
 */
process.env.JWT_SECRET = "test-secret-".padEnd(48, "x");
process.env.NODE_ENV = "test";

const request = require("supertest");
const express = require("express");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

jest.mock("../models/User", () => {
  const users = [];
  return {
    __users: users,
    findOne: jest.fn(({ email }) => ({ select: async () => users.find((u) => u.email === email) || null })),
    findById: jest.fn(async (id) => users.find((u) => String(u._id) === String(id)) || null),
    updateOne: jest.fn(async ({ _id }, update) => {
      const u = users.find((x) => String(x._id) === String(_id));
      if (u && update.$inc) for (const k of Object.keys(update.$inc)) u[k] += update.$inc[k];
    }),
  };
});

const User = require("../models/User");
const adminAuthRoutes = require("../routes/adminAuth");
const { authenticate, requireRole } = require("../middleware/auth");
const { JWT_SECRET, COOKIE_NAME } = require("../config/authConfig");

const ADMIN_PW = "Correct-Horse-Battery-9";
const CUSTOMER_PW = "customer-password-1";

function buildApp() {
  const app = express();
  app.use(express.json());
  app.use(cookieParser());
  app.use("/api/admin", adminAuthRoutes);
  const protectedRouter = express.Router();
  protectedRouter.get("/secret", (req, res) => res.json({ ok: true }));
  app.use("/api/admin", authenticate, requireRole("admin"), protectedRouter);
  return app;
}

const tokenFor = (u) => jwt.sign({ sub: u._id, role: u.role, tv: u.tokenVersion }, JWT_SECRET, { algorithm: "HS256", expiresIn: "1h" });
const withCookie = (t) => [`${COOKIE_NAME}=${t}`];

let app, admin, customer;

beforeAll(() => {
  admin = { _id: "a1", name: "Site Admin", email: "admin@test.com", role: "admin", tokenVersion: 0, isActive: true, passwordHash: bcrypt.hashSync(ADMIN_PW, 4) };
  customer = { _id: "c1", name: "Cust", email: "cust@test.com", role: "customer", tokenVersion: 0, isActive: true, passwordHash: bcrypt.hashSync(CUSTOMER_PW, 4) };
  User.__users.push(admin, customer);
  app = buildApp();
});

describe("admin login", () => {
  test("valid admin gets an HttpOnly cookie and no secrets in the body", async () => {
    const res = await request(app).post("/api/admin/login").send({ email: "admin@test.com", password: ADMIN_PW });
    expect(res.status).toBe(200);
    const cookie = res.headers["set-cookie"].join(";");
    expect(cookie).toContain(`${COOKIE_NAME}=`);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(res.body.user.role).toBe("admin");
    expect(JSON.stringify(res.body)).not.toMatch(/passwordHash|password|token/i);
  });

  test("wrong password -> 401 with a generic message", async () => {
    const res = await request(app).post("/api/admin/login").send({ email: "admin@test.com", password: "nope" });
    expect(res.status).toBe(401);
    expect(res.body.message).toBe("Invalid email or password.");
  });

  test("a customer cannot log in through the admin endpoint", async () => {
    const res = await request(app).post("/api/admin/login").send({ email: "cust@test.com", password: CUSTOMER_PW });
    expect(res.status).toBe(401);
    expect(res.headers["set-cookie"]).toBeUndefined();
  });
});

describe("protected admin routes", () => {
  test("no session -> 401", async () => {
    expect((await request(app).get("/api/admin/me")).status).toBe(401);
    expect((await request(app).get("/api/admin/secret")).status).toBe(401);
  });

  test("customer with a valid session -> 403 Forbidden", async () => {
    const t = tokenFor(customer);
    expect((await request(app).get("/api/admin/me").set("Cookie", withCookie(t))).status).toBe(403);
    expect((await request(app).get("/api/admin/secret").set("Cookie", withCookie(t))).status).toBe(403);
  });

  test("admin session -> 200", async () => {
    const t = tokenFor(admin);
    const res = await request(app).get("/api/admin/me").set("Cookie", withCookie(t));
    expect(res.status).toBe(200);
    expect(res.body.user.email).toBe("admin@test.com");
    expect((await request(app).get("/api/admin/secret").set("Cookie", withCookie(t))).status).toBe(200);
  });

  test("tampered token -> 401", async () => {
    const t = tokenFor(admin) + "x";
    expect((await request(app).get("/api/admin/me").set("Cookie", withCookie(t))).status).toBe(401);
  });
});

describe("logout", () => {
  test("clears the cookie and invalidates the old token on the server", async () => {
    const t = tokenFor(admin);
    expect((await request(app).get("/api/admin/me").set("Cookie", withCookie(t))).status).toBe(200);

    const out = await request(app).post("/api/admin/logout").set("Cookie", withCookie(t));
    expect(out.status).toBe(200);
    expect(out.headers["set-cookie"].join(";")).toMatch(new RegExp(`${COOKIE_NAME}=;`));

    // Wahi purana token ab bekaar hai (tokenVersion badh chuka hai)
    expect((await request(app).get("/api/admin/me").set("Cookie", withCookie(t))).status).toBe(401);
  });
});
