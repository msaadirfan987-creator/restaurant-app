// scripts/seedAdmin.js — pehla admin banata hai. Ek baar chalao: node scripts/seedAdmin.js
// Credentials .env se aate hain; code me koi password nahi. Password kabhi print nahi hota.
require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("../models/User");

async function main() {
  const { MONGODB_URI, ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_NAME } = process.env;
  if (!MONGODB_URI || !ADMIN_EMAIL || !ADMIN_PASSWORD) {
    throw new Error("Set MONGODB_URI, ADMIN_EMAIL and ADMIN_PASSWORD in your .env first.");
  }
  if (ADMIN_PASSWORD.length < 12) throw new Error("ADMIN_PASSWORD must be at least 12 characters.");

  await mongoose.connect(MONGODB_URI);
  const email = ADMIN_EMAIL.trim().toLowerCase();

  if (await User.findOne({ email })) {
    console.log("An account with this email already exists. Nothing changed.");
  } else {
    await User.create({
      name: ADMIN_NAME || "Admin",
      email,
      passwordHash: await bcrypt.hash(ADMIN_PASSWORD, 12),
      role: "admin",
    });
    console.log(`Admin created: ${email}`);
    console.log("Now REMOVE ADMIN_PASSWORD from your .env file.");
  }
  await mongoose.disconnect();
}

main().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
