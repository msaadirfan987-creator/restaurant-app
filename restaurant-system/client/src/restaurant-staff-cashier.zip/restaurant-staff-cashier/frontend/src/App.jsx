import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './pages/Login';
import AdminLayout from './pages/admin/AdminLayout';
import StaffManagement from './pages/admin/StaffManagement';
import CashierLayout from './pages/cashier/CashierLayout';
import Dashboard from './pages/cashier/Dashboard';
import POS from './pages/cashier/POS';
import OrdersPage from './pages/cashier/OrdersPage';
import Profile from './pages/cashier/Profile';
import KitchenPanel from './pages/kitchen/KitchenPanel';
import WaiterPanel from './pages/waiter/WaiterPanel';
import { ROLE_HOME } from './utils/format';

function Home() {
  const { user, loading } = useAuth();
  if (loading) return <div className="center-screen"><div className="spinner" /></div>;
  return <Navigate to={user ? ROLE_HOME[user.role] : '/login'} replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/cashier/login" element={<Login title="Cashier Login" />} />

      {/* ADMIN. Replace AdminLayout's content with your existing admin dashboard routes. */}
      <Route element={<ProtectedRoute roles={['admin']} />}>
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<Navigate to="staff" replace />} />
          <Route path="staff" element={<StaffManagement />} />
        </Route>
      </Route>

      {/* CASHIER */}
      <Route element={<ProtectedRoute roles={['cashier']} />}>
        <Route path="/cashier" element={<CashierLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="pos" element={<POS />} />
          <Route
            path="online"
            element={<OrdersPage key="online" title="Online Website Orders" fixed={{ source: 'online', group: 'active' }} poll filters={['status', 'paymentStatus', 'search']} />}
          />
          <Route
            path="dine-in"
            element={<OrdersPage key="dine" title="Dine-In Orders" fixed={{ type: 'dine-in', group: 'active' }} poll filters={['status', 'paymentStatus', 'search']} newDineIn />}
          />
          <Route path="orders" element={<OrdersPage key="all" title="All Orders" fixed={{}} poll filters={['source', 'type', 'status', 'paymentStatus', 'search', 'date']} />} />
          <Route
            path="history"
            element={<OrdersPage key="hist" title="Order History" fixed={{ group: 'past' }} filters={['source', 'type', 'status', 'paymentStatus', 'search', 'date']} />}
          />
          <Route path="profile" element={<Profile />} />
        </Route>
      </Route>

      {/* PLACEHOLDERS (structure ready for later development) */}
      <Route element={<ProtectedRoute roles={['kitchen']} />}>
        <Route path="/kitchen" element={<KitchenPanel />} />
      </Route>
      <Route element={<ProtectedRoute roles={['waiter']} />}>
        <Route path="/waiter" element={<WaiterPanel />} />
      </Route>

      <Route path="*" element={<Home />} />
    </Routes>
  );
}
