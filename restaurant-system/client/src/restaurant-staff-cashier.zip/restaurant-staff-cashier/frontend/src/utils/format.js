export const uuid = () =>
  (typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID()) ||
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;

export const fmtMoney = (n, currency = 'Rs') => `${currency} ${Number(n || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
export const fmtDate = (d) => (d ? new Date(d).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '-');
export const r2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;

// Mirrors the server formula for LIVE PREVIEW only. The server recalculates and is the source of truth.
export function previewTotals(cart, discountType, discountValue, taxRate) {
  const subtotal = r2(cart.reduce((s, i) => s + i.price * i.quantity, 0));
  let discount = 0;
  const v = Number(discountValue) || 0;
  if (discountType === 'percent') discount = r2(subtotal * (v / 100));
  if (discountType === 'amount') discount = r2(v);
  const tax = r2((subtotal - discount) * taxRate);
  return { subtotal, discount, tax, total: r2(subtotal - discount + tax) };
}

export const ROLE_HOME = { admin: '/admin', cashier: '/cashier', kitchen: '/kitchen', waiter: '/waiter' };
export const ROLE_LABEL = { admin: 'Admin', cashier: 'Cashier', kitchen: 'Kitchen Staff', waiter: 'Waiter' };
