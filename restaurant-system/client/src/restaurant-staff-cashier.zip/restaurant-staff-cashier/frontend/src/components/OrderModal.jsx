import { useState } from 'react';
import api, { errMsg } from '../api';
import { useConfig } from '../context/ConfigContext';
import { Modal, PayBadge, StatusBadge } from './ui';
import Receipt from './Receipt';
import { fmtDate, fmtMoney } from '../utils/format';

const NEXT = {
  pending: [{ to: 'preparing', label: 'Accept & start preparing', primary: true }],
  preparing: [{ to: 'ready', label: 'Mark ready', primary: true }],
  ready: [{ to: 'completed', label: 'Complete order', primary: true }],
};

export default function OrderModal({ order: initial, onClose, onChanged }) {
  const cfg = useConfig();
  const m = (n) => fmtMoney(n, cfg.currency);
  const [order, setOrder] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [showPay, setShowPay] = useState(false);
  const [received, setReceived] = useState(String(initial.total));
  const [showCancel, setShowCancel] = useState(false);
  const [reason, setReason] = useState('');
  const [showReceipt, setShowReceipt] = useState(false);

  const act = async (fn) => {
    if (busy) return; // blocks double-clicks
    setBusy(true);
    setErr('');
    try {
      const { data } = await fn();
      setOrder(data.order);
      onChanged?.(data.order);
      setShowPay(false);
      setShowCancel(false);
    } catch (e) {
      setErr(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  const setStatus = (status, rsn) => act(() => api.patch(`/cashier/orders/${order._id}/status`, { status, reason: rsn }));
  const pay = () => act(() => api.post(`/cashier/orders/${order._id}/pay`, { amountReceived: Number(received) }));

  const change = Number(received) - order.total;
  const open = ['pending', 'preparing', 'ready'].includes(order.status);
  const canPay = order.paymentStatus === 'unpaid' && order.status !== 'cancelled';
  const canCancel = open && order.paymentStatus === 'unpaid';

  return (
    <Modal title={`Order #${order.orderNumber}`} onClose={onClose} wide>
      {err && <div className="alert error">{err}</div>}
      <div className="detail-grid">
        <div>
          <div className="row wrap">
            <StatusBadge status={order.status} /><PayBadge status={order.paymentStatus} />
            <span className="badge">{order.source === 'online' ? 'website' : 'POS'}</span>
            <span className="badge">{order.type}{order.table ? ` - Table ${order.table.number}` : ''}</span>
          </div>
          <p className="muted small">Placed {fmtDate(order.createdAt)}{order.createdBy ? ` by ${order.createdBy.name}` : ''}</p>
          {(order.customer?.name || order.customer?.phone || order.customer?.address || order.customer?.notes) && (
            <div className="card flat">
              <strong>Customer</strong>
              {order.customer.name && <div>{order.customer.name}</div>}
              {order.customer.phone && <div>{order.customer.phone}</div>}
              {order.customer.address && <div>{order.customer.address}</div>}
              {order.customer.notes && <div className="muted">Note: {order.customer.notes}</div>}
            </div>
          )}
          {order.status === 'cancelled' && order.cancelReason && <div className="alert error">Cancelled: {order.cancelReason}</div>}
          <table className="mini">
            <thead><tr><th>Item</th><th>Qty</th><th className="r">Price</th></tr></thead>
            <tbody>
              {order.items.map((i, idx) => (
                <tr key={idx}><td>{i.name}</td><td>{i.quantity}</td><td className="r">{m(i.price * i.quantity)}</td></tr>
              ))}
            </tbody>
            <tfoot>
              <tr><td colSpan={2}>Subtotal</td><td className="r">{m(order.subtotal)}</td></tr>
              {order.discount > 0 && <tr><td colSpan={2}>Discount</td><td className="r">- {m(order.discount)}</td></tr>}
              <tr><td colSpan={2}>Tax</td><td className="r">{m(order.tax)}</td></tr>
              <tr className="grand"><td colSpan={2}>Total</td><td className="r">{m(order.total)}</td></tr>
            </tfoot>
          </table>
          {order.paymentStatus === 'paid' && (
            <p className="small">Cash received {m(order.amountReceived)} &middot; change {m(order.changeGiven)} &middot; {fmtDate(order.paidAt)}{order.receivedBy ? ` by ${order.receivedBy.name}` : ''}</p>
          )}
        </div>
      </div>

      {showPay && (
        <div className="card flat">
          <label>Cash received ({cfg.currency})
            <input type="number" min={order.total} step="0.01" value={received} onChange={(e) => setReceived(e.target.value)} autoFocus />
          </label>
          <p>Change due: <strong>{change >= 0 ? m(change) : '-'}</strong></p>
          <div className="row">
            <button className="btn" onClick={() => setShowPay(false)}>Back</button>
            <button className="btn primary" disabled={busy || !(change >= 0)} onClick={pay}>{busy ? 'Saving...' : 'Confirm cash received'}</button>
          </div>
        </div>
      )}

      {showCancel && (
        <div className="card flat">
          <label>Reason (optional)<input value={reason} maxLength={200} onChange={(e) => setReason(e.target.value)} autoFocus /></label>
          <div className="row">
            <button className="btn" onClick={() => setShowCancel(false)}>Back</button>
            <button className="btn danger" disabled={busy} onClick={() => setStatus('cancelled', reason)}>{order.status === 'pending' ? 'Reject order' : 'Cancel order'}</button>
          </div>
        </div>
      )}

      {!showPay && !showCancel && (
        <div className="row wrap action-bar">
          {canPay && <button className="btn primary" disabled={busy} onClick={() => { setReceived(String(order.total)); setShowPay(true); }}>Receive cash</button>}
          {(NEXT[order.status] || []).map((a) => {
            const blocked = a.to === 'completed' && order.paymentStatus !== 'paid';
            return (
              <button key={a.to} className={`btn ${a.primary && !canPay ? 'primary' : ''}`} disabled={busy || blocked}
                title={blocked ? 'Receive cash first' : ''} onClick={() => setStatus(a.to)}>
                {a.label}
              </button>
            );
          })}
          {canCancel && <button className="btn danger" disabled={busy} onClick={() => setShowCancel(true)}>{order.status === 'pending' ? 'Reject' : 'Cancel'}</button>}
          <button className="btn" onClick={() => setShowReceipt((v) => !v)}>{showReceipt ? 'Hide receipt' : 'Receipt'}</button>
        </div>
      )}

      {showReceipt && (
        <div>
          <Receipt order={order} />
          <button className="btn primary" onClick={() => window.print()}>Print receipt</button>
        </div>
      )}
    </Modal>
  );
}
