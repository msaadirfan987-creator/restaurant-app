import { useConfig } from '../context/ConfigContext';
import { fmtDate, fmtMoney } from '../utils/format';

// Rendered inside a modal. window.print() prints ONLY .receipt-print (see @media print in styles.css)
export default function Receipt({ order }) {
  const cfg = useConfig();
  const m = (n) => fmtMoney(n, cfg.currency);
  return (
    <div className="receipt-print">
      <div className="receipt">
        <h2>{cfg.restaurantName}</h2>
        <p className="center">Order #{order.orderNumber}</p>
        <p className="center small">{fmtDate(order.createdAt)}</p>
        <hr />
        <p className="small">
          {order.type === 'dine-in' ? `Dine-in${order.table ? ` - Table ${order.table.number}` : ''}` : order.type}
          {order.customer?.name ? ` | ${order.customer.name}` : ''}
          {order.customer?.phone ? ` | ${order.customer.phone}` : ''}
        </p>
        <hr />
        {order.items.map((i, idx) => (
          <div className="r-row" key={idx}>
            <span>{i.quantity} x {i.name}</span>
            <span>{m(i.price * i.quantity)}</span>
          </div>
        ))}
        <hr />
        <div className="r-row"><span>Subtotal</span><span>{m(order.subtotal)}</span></div>
        {order.discount > 0 && <div className="r-row"><span>Discount</span><span>- {m(order.discount)}</span></div>}
        <div className="r-row"><span>Tax ({Math.round((order.taxRate || 0) * 10000) / 100}%)</span><span>{m(order.tax)}</span></div>
        <div className="r-row total"><span>TOTAL</span><span>{m(order.total)}</span></div>
        <hr />
        {order.paymentStatus === 'paid' ? (
          <>
            <div className="r-row"><span>Paid (cash)</span><span>{m(order.amountReceived)}</span></div>
            <div className="r-row"><span>Change</span><span>{m(order.changeGiven)}</span></div>
            <p className="center small">Paid {fmtDate(order.paidAt)}</p>
          </>
        ) : (
          <p className="center"><strong>UNPAID - payment pending</strong></p>
        )}
        <p className="center small">Thank you for dining with us!</p>
      </div>
    </div>
  );
}
