import { useEffect } from 'react';

export const Spinner = ({ label = 'Loading...' }) => (
  <div className="state-box"><div className="spinner" /><p>{label}</p></div>
);
export const Empty = ({ children }) => <div className="state-box muted">{children}</div>;
export const ErrorBox = ({ message, onRetry }) => (
  <div className="state-box error-box">
    <p>{message}</p>
    {onRetry && <button className="btn" onClick={onRetry}>Retry</button>}
  </div>
);

export function Modal({ title, onClose, children, wide, footer }) {
  useEffect(() => {
    const h = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);
  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true">
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="icon-btn" onClick={onClose} aria-label="Close">&times;</button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

export const StatusBadge = ({ status }) => <span className={`badge st-${status}`}>{status}</span>;
export const PayBadge = ({ status }) => <span className={`badge pay-${status}`}>{status}</span>;
