import { Modal } from './ui';
import Receipt from './Receipt';

export default function ReceiptModal({ order, onClose }) {
  return (
    <Modal
      title={`Receipt #${order.orderNumber}`}
      onClose={onClose}
      footer={
        <>
          <button className="btn" onClick={onClose}>Close</button>
          <button className="btn primary" onClick={() => window.print()}>Print</button>
        </>
      }
    >
      <Receipt order={order} />
    </Modal>
  );
}
