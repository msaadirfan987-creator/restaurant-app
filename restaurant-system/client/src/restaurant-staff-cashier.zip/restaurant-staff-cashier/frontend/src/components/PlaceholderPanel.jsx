import { useAuth } from '../context/AuthContext';
import { ROLE_LABEL } from '../utils/format';

export default function PlaceholderPanel({ heading }) {
  const { user, logout } = useAuth();
  return (
    <div className="center-screen">
      <div className="card placeholder">
        <h1>{heading}</h1>
        <p className="muted">{user.name} &middot; {ROLE_LABEL[user.role]}</p>
        <button className="btn primary" onClick={logout}>Logout</button>
      </div>
    </div>
  );
}
