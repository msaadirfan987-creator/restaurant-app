import { createContext, useContext, useEffect, useState } from 'react';
import api from '../api';

const ConfigContext = createContext({ restaurantName: 'Restaurant', currency: 'Rs', taxRate: 0, maxDiscountPercent: 0 });

export function ConfigProvider({ children }) {
  const [cfg, setCfg] = useState({ restaurantName: 'Restaurant', currency: 'Rs', taxRate: 0, maxDiscountPercent: 0 });
  useEffect(() => {
    api.get('/config').then((r) => setCfg(r.data)).catch(() => {});
  }, []);
  return <ConfigContext.Provider value={cfg}>{children}</ConfigContext.Provider>;
}
export const useConfig = () => useContext(ConfigContext);
