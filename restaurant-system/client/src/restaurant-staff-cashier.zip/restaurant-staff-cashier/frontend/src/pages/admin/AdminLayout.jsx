import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export default function AdminLayout() {
  const { user, logout } = useAuth();
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">Admin</div>
        <nav>
          <NavLink to="/admin/staff">Staff Management</NavLink>
          {/* add your existing admin links here (menu, orders, reports...) */}
        </nav>
        <div className="side-foot">
          <div className="small">{user.name}<br /><span className="muted">{user.email}</span></div>
          <button className="btn block" onClick={logout}>Logout</button>
        </div>
      </aside>
      <main className="content"><Outlet /></main>
    </div>
  );
}
