import PlaceholderPanel from '../../components/PlaceholderPanel';
// TODO: waiter order-taking / table service goes here later.
export default function WaiterPanel() {
  return <PlaceholderPanel heading="Welcome to the Waiter Panel" />;
}
