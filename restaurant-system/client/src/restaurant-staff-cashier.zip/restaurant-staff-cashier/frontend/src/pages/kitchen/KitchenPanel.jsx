import PlaceholderPanel from '../../components/PlaceholderPanel';
// TODO: kitchen order queue goes here later.
export default function KitchenPanel() {
  return <PlaceholderPanel heading="Welcome to the Kitchen Panel" />;
}
