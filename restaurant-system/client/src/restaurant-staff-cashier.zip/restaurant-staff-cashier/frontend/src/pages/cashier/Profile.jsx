import { useState } from 'react';
import api, { errMsg } from '../../api';
import { useAuth } from '../../context/AuthContext';
import { ROLE_LABEL } from '../../utils/format';

export default function Profile() {
  const { user, setUser } = useAuth();
  const [name, setName] = useState(user.name);
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [msg, setMsg] = useState({ profile: null, pw: null });
  const [busy, setBusy] = useState(false);

  const saveName = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const { data } = await api.patch('/auth/profile', { name });
      setUser(data.user);
      setMsg({ ...msg, profile: { ok: true, text: 'Name updated' } });
    } catch (err) {
      setMsg({ ...msg, profile: { ok: false, text: errMsg(err) } });
    } finally { setBusy(false); }
  };

  const savePw = async (e) => {
    e.preventDefault();
    if (pw.newPassword !== pw.confirm) return setMsg({ ...msg, pw: { ok: false, text: 'Passwords do not match' } });
    setBusy(true);
    try {
      await api.patch('/auth/password', { currentPassword: pw.currentPassword, newPassword: pw.newPassword });
      setPw({ currentPassword: '', newPassword: '', confirm: '' });
      setMsg({ ...msg, pw: { ok: true, text: 'Password changed' } });
    } catch (err) {
      setMsg({ ...msg, pw: { ok: false, text: errMsg(err) } });
    } finally { setBusy(false); }
  };

  const Note = ({ m }) => m && <div className={`alert ${m.ok ? 'ok' : 'error'}`}>{m.text}</div>;

  return (
    <div className="narrow">
      <div className="page-head"><h1>My Profile</h1></div>
      <div className="card form">
        <div><span className="muted small">Email</span><div>{user.email}</div></div>
        <div><span className="muted small">Role</span><div>{ROLE_LABEL[user.role]}</div></div>
        <p className="muted small">Email and role can only be changed by an admin.</p>
      </div>

      <form className="card form" onSubmit={saveName}>
        <h3>Display name</h3>
        <Note m={msg.profile} />
        <input value={name} onChange={(e) => setName(e.target.value)} required minLength={2} maxLength={80} />
        <button className="btn primary" disabled={busy || name.trim() === user.name}>Save name</button>
      </form>

      <form className="card form" onSubmit={savePw}>
        <h3>Change password</h3>
        <Note m={msg.pw} />
        <label>Current password<input type="password" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} required autoComplete="current-password" /></label>
        <label>New password (min 8)<input type="password" value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} required minLength={8} maxLength={72} autoComplete="new-password" /></label>
        <label>Confirm new password<input type="password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} required autoComplete="new-password" /></label>
        <button className="btn primary" disabled={busy}>Change password</button>
      </form>
    </div>
  );
}
