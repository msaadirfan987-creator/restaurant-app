import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../../api';
import { useConfig } from '../../context/ConfigContext';
import { Empty, ErrorBox, PayBadge, Spinner, StatusBadge } from '../../components/ui';
import OrderModal from '../../components/OrderModal';
import { fmtDate, fmtMoney } from '../../utils/format';

/**
 * One reusable list powering: Online Orders, Dine-In Orders, All Orders, Order History.
 * `fixed` = server filters locked for that page, `filters` = which controls to show.
 */
export default function OrdersPage({ title, fixed, filters, poll, newDineIn }) {
  const cfg = useConfig();
  const [f, setF] = useState({ status: '', paymentStatus: '', source: '', type: '', search: '', from: '', to: '' });
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState(null);
  const reqId = useRef(0);

  useEffect(() => {
    const t = setTimeout(() => { setF((p) => ({ ...p, search })); setPage(1); }, 350);
    return () => clearTimeout(t);
  }, [search]);

  const params = useMemo(() => {
    const p = { ...fixed, page, limit: 20 };
    Object.entries(f).forEach(([k, v]) => { if (v) p[k] = v; });
    return p;
  }, [fixed, f, page]);

  const load = useCallback(async (silent) => {
    const id = ++reqId.current;
    if (!silent) setLoading(true);
    try {
      const { data: d } = await api.get('/cashier/orders', { params });
      if (id === reqId.current) { setData(d); setError(''); }
    } catch (e) {
      if (id === reqId.current) setError(errMsg(e));
    } finally {
      if (id === reqId.current) setLoading(false);
    }
  }, [params]);

  useEffect(() => { load(false); }, [load]);
  useEffect(() => {
    if (!poll) return;
    const t = setInterval(() => !selected && load(true), 15000); // auto-refresh incoming orders
    return () => clearInterval(t);
  }, [poll, load, selected]);

  const setFilter = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setPage(1); };
  const has = (k) => filters.includes(k);
  const m = (n) => fmtMoney(n, cfg.currency);

  return (
    <div>
      <div className="page-head">
        <h1>{title}</h1>
        <div className="row">
          <button className="btn" onClick={() => load(false)}>Refresh</button>
          {newDineIn && <Link className="btn primary" to="/cashier/pos?type=dine-in">+ New dine-in order</Link>}
        </div>
      </div>

      <div className="filters">
        {has('search') && <input placeholder="Search order #, customer, phone..." value={search} onChange={(e) => setSearch(e.target.value)} />}
        {has('status') && (
          <select value={f.status} onChange={setFilter('status')}>
            <option value="">Any status</option>
            {['pending', 'preparing', 'ready', 'completed', 'cancelled'].map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        )}
        {has('paymentStatus') && (
          <select value={f.paymentStatus} onChange={setFilter('paymentStatus')}>
            <option value="">Paid + unpaid</option><option value="unpaid">Unpaid</option><option value="paid">Paid</option>
          </select>
        )}
        {has('source') && (
          <select value={f.source} onChange={setFilter('source')}>
            <option value="">Website + POS</option><option value="online">Website</option><option value="pos">POS</option>
          </select>
        )}
        {has('type') && (
          <select value={f.type} onChange={setFilter('type')}>
            <option value="">All types</option><option value="dine-in">Dine-in</option><option value="takeaway">Takeaway</option><option value="delivery">Delivery</option>
          </select>
        )}
        {has('date') && (
          <>
            <input type="date" value={f.from} onChange={setFilter('from')} title="From" />
            <input type="date" value={f.to} onChange={setFilter('to')} title="To" />
          </>
        )}
      </div>

      {loading && !data ? <Spinner /> : error && !data ? <ErrorBox message={error} onRetry={() => load(false)} /> : !data?.orders.length ? (
        <Empty>No orders found.</Empty>
      ) : (
        <>
          {error && <div className="alert error">{error}</div>}
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>#</th><th>Date &amp; time</th><th>Type</th><th>Customer</th><th>Items</th><th className="r">Total</th><th>Payment</th><th>Status</th><th /></tr>
              </thead>
              <tbody>
                {data.orders.map((o) => (
                  <tr key={o._id} className="click" onClick={() => setSelected(o)}>
                    <td><strong>#{o.orderNumber}</strong><div className="muted small">{o.source === 'online' ? 'website' : 'POS'}</div></td>
                    <td>{fmtDate(o.createdAt)}</td>
                    <td>{o.type}{o.table ? ` (T${o.table.number})` : ''}</td>
                    <td>{o.customer?.name || '-'}<div className="muted small">{o.customer?.phone}</div></td>
                    <td className="items-cell">{o.items.map((i) => `${i.quantity}x ${i.name}`).join(', ')}</td>
                    <td className="r">{m(o.total)}</td>
                    <td><PayBadge status={o.paymentStatus} /></td>
                    <td><StatusBadge status={o.status} /></td>
                    <td><button className="btn sm">Open</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="pager">
            <button className="btn sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>Prev</button>
            <span>Page {data.page} of {data.pages} &middot; {data.total} orders</span>
            <button className="btn sm" disabled={page >= data.pages} onClick={() => setPage(page + 1)}>Next</button>
          </div>
        </>
      )}

      {selected && (
        <OrderModal
          order={selected}
          onClose={() => { setSelected(null); load(true); }}
          onChanged={(o) => setSelected(o)}
        />
      )}
    </div>
  );
}
