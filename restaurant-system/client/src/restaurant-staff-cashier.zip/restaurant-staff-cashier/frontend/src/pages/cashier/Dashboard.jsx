import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../../api';
import { useConfig } from '../../context/ConfigContext';
import { ErrorBox, Spinner } from '../../components/ui';
import { fmtMoney } from '../../utils/format';

export default function Dashboard() {
  const cfg = useConfig();
  const [s, setS] = useState(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try {
      const { data } = await api.get('/cashier/stats');
      setS(data);
      setError('');
    } catch (e) {
      setError(errMsg(e));
    }
  }, []);
  useEffect(() => {
    load();
    const t = setInterval(load, 20000);
    return () => clearInterval(t);
  }, [load]);

  if (error && !s) return <ErrorBox message={error} onRetry={load} />;
  if (!s) return <Spinner />;

  const cards = [
    ['Today\'s orders', s.ordersToday],
    ['Today\'s cash sales', fmtMoney(s.cashSalesToday, cfg.currency), `${s.paymentsToday} payments`],
    ['Pending orders', s.pending, `${s.onlinePending} from website`],
    ['Completed today', s.completedToday],
    ['Unpaid active orders', s.unpaidActive],
  ];

  return (
    <div>
      <div className="page-head"><h1>Dashboard</h1></div>
      {error && <div className="alert error">{error}</div>}
      <div className="stat-grid">
        {cards.map(([label, value, sub]) => (
          <div className="card stat" key={label}>
            <div className="muted small">{label}</div>
            <div className="stat-value">{value}</div>
            {sub && <div className="muted small">{sub}</div>}
          </div>
        ))}
      </div>
      <h3>Quick actions</h3>
      <div className="row">
        <Link className="btn primary lg" to="/cashier/pos">+ New order</Link>
        <Link className="btn lg" to="/cashier/online">Incoming website orders{s.onlinePending > 0 && <span className="pill">{s.onlinePending}</span>}</Link>
        <Link className="btn lg" to="/cashier/dine-in">Dine-in orders</Link>
      </div>
    </div>
  );
}
