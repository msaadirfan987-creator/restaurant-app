import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api, { errMsg } from '../../api';
import { useConfig } from '../../context/ConfigContext';
import { Empty, ErrorBox, Spinner } from '../../components/ui';
import ReceiptModal from '../../components/ReceiptModal';
import { fmtMoney, previewTotals, uuid } from '../../utils/format';

export default function POS() {
  const cfg = useConfig();
  const [params] = useSearchParams();
  const m = (n) => fmtMoney(n, cfg.currency);

  const [menu, setMenu] = useState([]);
  const [tables, setTables] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  const [cat, setCat] = useState('All');
  const [q, setQ] = useState('');
  const [cart, setCart] = useState([]); // [{menuItem, name, price, quantity}]
  const [type, setType] = useState(params.get('type') === 'dine-in' ? 'dine-in' : 'takeaway');
  const [table, setTable] = useState('');
  const [customer, setCustomer] = useState({ name: '', phone: '' });
  const [discountType, setDiscountType] = useState('none');
  const [discountValue, setDiscountValue] = useState('');
  const [payNow, setPayNow] = useState(false);
  const [received, setReceived] = useState('');

  // one key per "cart session": a retry/double-click re-sends the SAME key, so the server returns the same order
  const [clientKey, setClientKey] = useState(uuid);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError('');
    try {
      const [mn, tb] = await Promise.all([api.get('/menu'), api.get('/tables')]);
      setMenu(mn.data.items);
      setTables(tb.data.tables);
    } catch (e) {
      setLoadError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { load(); }, [load]);

  const categories = useMemo(() => ['All', ...new Set(menu.map((i) => i.category))], [menu]);
  const visible = useMemo(
    () => menu.filter((i) => (cat === 'All' || i.category === cat) && i.name.toLowerCase().includes(q.trim().toLowerCase())),
    [menu, cat, q]
  );

  const add = (item) =>
    setCart((c) => {
      const ex = c.find((l) => l.menuItem === item._id);
      if (ex) return c.map((l) => (l.menuItem === item._id ? { ...l, quantity: Math.min(50, l.quantity + 1) } : l));
      return [...c, { menuItem: item._id, name: item.name, price: item.price, quantity: 1 }];
    });
  const change = (id, d) =>
    setCart((c) => c.map((l) => (l.menuItem === id ? { ...l, quantity: l.quantity + d } : l)).filter((l) => l.quantity > 0 && l.quantity <= 50));
  const remove = (id) => setCart((c) => c.filter((l) => l.menuItem !== id));

  const totals = previewTotals(cart, discountType, discountValue, cfg.taxRate);
  const maxDisc = totals.subtotal * (cfg.maxDiscountPercent / 100);
  const discountTooHigh = totals.discount > maxDisc + 0.001;
  const changeDue = Number(received) - totals.total;

  const reset = () => {
    setCart([]); setTable(''); setCustomer({ name: '', phone: '' });
    setDiscountType('none'); setDiscountValue(''); setPayNow(false); setReceived('');
    setClientKey(uuid()); setError('');
  };

  const validate = () => {
    if (!cart.length) return 'Add at least one item';
    if (type === 'dine-in' && !table) return 'Select a table for dine-in';
    if (type === 'takeaway' && !customer.name.trim()) return 'Customer name is required for takeaway';
    if (discountTooHigh) return `Discount cannot exceed ${cfg.maxDiscountPercent}% of subtotal`;
    if (payNow && !(changeDue >= 0)) return 'Cash received must cover the total';
    return '';
  };

  const submit = async () => {
    if (submitting) return;
    const v = validate();
    if (v) return setError(v);
    setSubmitting(true);
    setError('');
    try {
      const body = {
        clientKey, type,
        table: type === 'dine-in' ? table : undefined,
        customer,
        items: cart.map((l) => ({ menuItem: l.menuItem, quantity: l.quantity })), // no prices sent
        discountType, discountValue: Number(discountValue) || 0,
        payNow, amountReceived: payNow ? Number(received) : undefined,
      };
      const { data } = await api.post('/cashier/orders', body);
      setDone(data.order); // server-calculated order -> receipt
      reset();
      api.get('/tables').then((r) => setTables(r.data.tables)).catch(() => {});
    } catch (e) {
      setError(errMsg(e)); // clientKey kept: pressing confirm again is safe
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <Spinner />;
  if (loadError) return <ErrorBox message={loadError} onRetry={load} />;

  return (
    <div className="pos">
      <section className="pos-menu">
        <div className="page-head"><h1>New Order</h1></div>
        <div className="filters">
          <input placeholder="Search menu..." value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="chips">
          {categories.map((c) => (
            <button key={c} className={`chip ${cat === c ? 'active' : ''}`} onClick={() => setCat(c)}>{c}</button>
          ))}
        </div>
        {menu.length === 0 ? <Empty>No menu items in the database yet. Add items first.</Empty> : visible.length === 0 ? <Empty>No items match.</Empty> : (
          <div className="menu-grid">
            {visible.map((i) => (
              <button key={i._id} className="menu-card" onClick={() => add(i)}>
                <span className="mc-name">{i.name}</span>
                <span className="muted small">{i.category}</span>
                <span className="mc-price">{m(i.price)}</span>
              </button>
            ))}
          </div>
        )}
      </section>

      <aside className="pos-cart card">
        <h3>Current order</h3>
        <div className="seg">
          <button className={type === 'takeaway' ? 'active' : ''} onClick={() => setType('takeaway')}>Takeaway</button>
          <button className={type === 'dine-in' ? 'active' : ''} onClick={() => setType('dine-in')}>Dine-in</button>
        </div>

        {type === 'dine-in' && (
          <label>Table
            <select value={table} onChange={(e) => setTable(e.target.value)}>
              <option value="">Select table...</option>
              {tables.map((t) => <option key={t._id} value={t._id}>Table {t.number} ({t.seats} seats){t.busy ? ' - occupied' : ''}</option>)}
            </select>
          </label>
        )}
        <div className="row">
          <input placeholder={type === 'takeaway' ? 'Customer name *' : 'Customer name'} value={customer.name} maxLength={80} onChange={(e) => setCustomer({ ...customer, name: e.target.value })} />
          <input placeholder="Phone" value={customer.phone} maxLength={20} onChange={(e) => setCustomer({ ...customer, phone: e.target.value })} />
        </div>

        <div className="cart-lines">
          {cart.length === 0 ? <Empty>Cart is empty. Tap menu items to add.</Empty> : cart.map((l) => (
            <div className="cart-line" key={l.menuItem}>
              <div className="cl-name">{l.name}<div className="muted small">{m(l.price)}</div></div>
              <div className="qty">
                <button onClick={() => change(l.menuItem, -1)} aria-label="decrease">-</button>
                <span>{l.quantity}</span>
                <button onClick={() => change(l.menuItem, 1)} aria-label="increase">+</button>
              </div>
              <div className="cl-total">{m(l.price * l.quantity)}</div>
              <button className="icon-btn" onClick={() => remove(l.menuItem)} aria-label="remove">&times;</button>
            </div>
          ))}
        </div>

        <div className="row">
          <select value={discountType} onChange={(e) => { setDiscountType(e.target.value); setDiscountValue(''); }}>
            <option value="none">No discount</option><option value="percent">Discount %</option><option value="amount">Discount {cfg.currency}</option>
          </select>
          {discountType !== 'none' && (
            <input type="number" min="0" step="0.01" placeholder="Value" value={discountValue} onChange={(e) => setDiscountValue(e.target.value)} />
          )}
        </div>

        <div className="totals">
          <div><span>Subtotal</span><span>{m(totals.subtotal)}</span></div>
          {totals.discount > 0 && <div><span>Discount</span><span>- {m(totals.discount)}</span></div>}
          <div><span>Tax ({Math.round(cfg.taxRate * 10000) / 100}%)</span><span>{m(totals.tax)}</span></div>
          <div className="grand"><span>Total</span><span>{m(totals.total)}</span></div>
        </div>

        <label className="check"><input type="checkbox" checked={payNow} onChange={(e) => { setPayNow(e.target.checked); setReceived(String(totals.total)); }} /> Receive cash payment now</label>
        {payNow && (
          <div>
            <input type="number" min={totals.total} step="0.01" value={received} onChange={(e) => setReceived(e.target.value)} placeholder="Cash received" />
            <p className="small">Change due: <strong>{changeDue >= 0 ? m(changeDue) : '-'}</strong></p>
          </div>
        )}
        {!payNow && <p className="muted small">Order will be saved as UNPAID. Take cash later from the order screen.</p>}

        {error && <div className="alert error">{error}</div>}
        <button className="btn primary block lg" disabled={submitting || !cart.length} onClick={submit}>
          {submitting ? 'Placing order...' : payNow ? 'Confirm & take cash' : 'Confirm order'}
        </button>
        {cart.length > 0 && <button className="btn block" onClick={reset} disabled={submitting}>Clear</button>}
      </aside>

      {done && <ReceiptModal order={done} onClose={() => setDone(null)} />}
    </div>
  );
}
