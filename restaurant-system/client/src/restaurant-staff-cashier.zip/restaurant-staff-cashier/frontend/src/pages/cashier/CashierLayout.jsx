import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useConfig } from '../../context/ConfigContext';

const links = [
  ['/cashier', 'Dashboard', true],
  ['/cashier/pos', 'New Order / POS'],
  ['/cashier/online', 'Online Orders'],
  ['/cashier/dine-in', 'Dine-In Orders'],
  ['/cashier/orders', 'All Orders'],
  ['/cashier/history', 'Order History'],
  ['/cashier/profile', 'Profile'],
];

export default function CashierLayout() {
  const { user, logout } = useAuth();
  const cfg = useConfig();
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">{cfg.restaurantName}<span className="muted small block">Cashier</span></div>
        <nav>
          {links.map(([to, label, end]) => (
            <NavLink key={to} to={to} end={end}>{label}</NavLink>
          ))}
        </nav>
        <div className="side-foot">
          <div className="small">{user.name}<br /><span className="muted">{user.email}</span></div>
          <button className="btn block" onClick={logout}>Logout</button>
        </div>
      </aside>
      <main className="content"><Outlet /></main>
    </div>
  );
}
