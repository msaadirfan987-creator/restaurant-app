import { useCallback, useEffect, useState } from 'react';
import api, { errMsg } from '../../api';
import { useAuth } from '../../context/AuthContext';
import { Empty, ErrorBox, Modal, Spinner } from '../../components/ui';
import { ROLE_LABEL, fmtDate } from '../../utils/format';

const ROLES = Object.keys(ROLE_LABEL);

function genPassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789@#$%';
  const arr = new Uint32Array(14);
  (window.crypto || window.msCrypto).getRandomValues(arr);
  return Array.from(arr, (n) => chars[n % chars.length]).join('');
}

function StaffForm({ initial, onClose, onSaved, isSelf }) {
  const editing = !!initial;
  const [form, setForm] = useState({ name: initial?.name || '', email: initial?.email || '', role: initial?.role || 'cashier', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    setBusy(true);
    try {
      if (editing) await api.patch(`/staff/${initial._id}`, { name: form.name, email: form.email, role: form.role });
      else await api.post('/staff', form);
      onSaved();
    } catch (e2) {
      setErr(errMsg(e2));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title={editing ? 'Edit staff member' : 'Add staff member'} onClose={onClose}>
      <form onSubmit={submit} className="form">
        {err && <div className="alert error">{err}</div>}
        <label>Full name<input value={form.name} onChange={set('name')} required minLength={2} maxLength={80} /></label>
        <label>Email<input type="email" value={form.email} onChange={set('email')} required /></label>
        <label>Role
          <select value={form.role} onChange={set('role')} disabled={isSelf}>
            {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
          </select>
          {isSelf && <span className="muted small">You cannot change your own role.</span>}
        </label>
        {!editing && (
          <label>Password (min 8)
            <div className="row">
              <input type="text" value={form.password} onChange={set('password')} required minLength={8} maxLength={72} autoComplete="new-password" />
              <button type="button" className="btn" onClick={() => setForm({ ...form, password: genPassword() })}>Generate</button>
            </div>
          </label>
        )}
        <div className="modal-foot-inline">
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className="btn primary" disabled={busy}>{busy ? 'Saving...' : 'Save'}</button>
        </div>
      </form>
    </Modal>
  );
}

function ResetPassword({ staff, onClose, onDone }) {
  const [pw, setPw] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setErr('');
    try {
      await api.post(`/staff/${staff._id}/reset-password`, { newPassword: pw });
      onDone();
    } catch (e2) {
      setErr(errMsg(e2));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal title={`Reset password - ${staff.name}`} onClose={onClose}>
      <form onSubmit={submit} className="form">
        {err && <div className="alert error">{err}</div>}
        <p className="muted small">All of this user's active sessions will be signed out.</p>
        <label>New password (min 8)
          <div className="row">
            <input type="text" value={pw} onChange={(e) => setPw(e.target.value)} required minLength={8} maxLength={72} autoComplete="new-password" />
            <button type="button" className="btn" onClick={() => setPw(genPassword())}>Generate</button>
          </div>
        </label>
        <div className="modal-foot-inline">
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className="btn primary" disabled={busy}>{busy ? 'Resetting...' : 'Reset password'}</button>
        </div>
      </form>
    </Modal>
  );
}

export default function StaffManagement() {
  const { user: me } = useAuth();
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [debounced, setDebounced] = useState('');
  const [role, setRole] = useState('');
  const [status, setStatus] = useState('');
  const [modal, setModal] = useState(null); // {type:'form'|'reset', staff?}
  const [notice, setNotice] = useState('');

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search), 300);
    return () => clearTimeout(t);
  }, [search]);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const { data } = await api.get('/staff', { params: { search: debounced, role, status } });
      setStaff(data.staff);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [debounced, role, status]);
  useEffect(() => { load(); }, [load]);

  const flash = (m) => { setNotice(m); setTimeout(() => setNotice(''), 4000); };

  const toggle = async (s) => {
    if (!window.confirm(`${s.isActive ? 'Deactivate' : 'Activate'} ${s.name}?`)) return;
    try {
      await api.patch(`/staff/${s._id}/status`, { isActive: !s.isActive });
      flash(`${s.name} ${s.isActive ? 'deactivated' : 'activated'}`);
      load();
    } catch (e) {
      setError(errMsg(e));
    }
  };

  return (
    <div>
      <div className="page-head">
        <h1>Staff Management</h1>
        <button className="btn primary" onClick={() => setModal({ type: 'form' })}>+ Add staff</button>
      </div>
      {notice && <div className="alert ok">{notice}</div>}

      <div className="filters">
        <input placeholder="Search name or email..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <select value={role} onChange={(e) => setRole(e.target.value)}>
          <option value="">All roles</option>
          {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
        </select>
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Active + inactive</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>

      {loading ? <Spinner /> : error ? <ErrorBox message={error} onRetry={load} /> : staff.length === 0 ? (
        <Empty>No staff found.</Empty>
      ) : (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Last login</th><th /></tr></thead>
            <tbody>
              {staff.map((s) => (
                <tr key={s._id}>
                  <td>{s.name}{s._id === me._id && <span className="muted small"> (you)</span>}</td>
                  <td>{s.email}</td>
                  <td>{ROLE_LABEL[s.role]}</td>
                  <td><span className={`badge ${s.isActive ? 'pay-paid' : 'st-cancelled'}`}>{s.isActive ? 'active' : 'inactive'}</span></td>
                  <td>{fmtDate(s.lastLoginAt)}</td>
                  <td className="actions">
                    <button className="btn sm" onClick={() => setModal({ type: 'form', staff: s })}>Edit</button>
                    <button className="btn sm" onClick={() => setModal({ type: 'reset', staff: s })}>Reset password</button>
                    {s._id !== me._id && <button className="btn sm" onClick={() => toggle(s)}>{s.isActive ? 'Deactivate' : 'Activate'}</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modal?.type === 'form' && (
        <StaffForm initial={modal.staff} isSelf={modal.staff?._id === me._id} onClose={() => setModal(null)}
          onSaved={() => { setModal(null); flash('Saved'); load(); }} />
      )}
      {modal?.type === 'reset' && (
        <ResetPassword staff={modal.staff} onClose={() => setModal(null)} onDone={() => { setModal(null); flash('Password reset'); }} />
      )}
    </div>
  );
}
