import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The proxy keeps the API same-origin in dev, so the httpOnly auth cookie "just works".
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, host: true, proxy: { '/api': 'http://localhost:5000' } },
});
