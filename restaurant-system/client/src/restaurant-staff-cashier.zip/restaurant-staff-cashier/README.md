# Restaurant: Staff Management + Role-Based Login + Cashier Panel

Stack: MERN (Express + Mongoose, React + Vite). Auth = JWT in an **httpOnly cookie**, passwords hashed with **bcrypt (12 rounds)**.

## 1. Setup (5 minutes)

```bash
# --- backend ---
cd backend
cp .env.example .env        # then edit: MONGO_URI, JWT_SECRET (32+ chars), TAX_RATE, RESTAURANT_NAME, ADMIN_EMAIL/PASSWORD
npm install
npm run seed                # creates first admin (+ starter menu & 10 tables ONLY if those collections are empty)
npm run dev                 # http://localhost:5000

# --- frontend (new terminal) ---
cd frontend
npm install
npm run dev                 # http://localhost:5173  (Vite proxies /api -> :5000, so cookies work)
```

Login: `http://localhost:5173/login` with the admin from `.env`. Then: Admin -> Staff Management -> create Cashier / Kitchen / Waiter accounts -> log in with each.
(`/cashier/login` is the same login screen titled "Cashier Login"; every role is redirected to *its own* panel.)

## 2. Apne existing project mein merge karna

Aap ke project mein abhi models/auth nahi hain, is liye ye module standalone hai. Merge karte waqt:
- **User model**: agar pehle se User model hai to `models/User.js` ke fields (`role`, `isActive`, `tokenVersion`, `password select:false`) apne model mein add karein, naya conflicting model na banayein.
- **MenuItem / Table / Order**: agar aap ke paas pehle se hain to unhe `services/orderService.js` mein map kar lein (field names: name, price, isAvailable).
- **Admin dashboard**: `pages/admin/AdminLayout.jsx` mein apni existing admin links add karein; Staff Management ek route hai (`/admin/staff`).
- **Website orders**: customer website/QR page ko `POST /api/orders` call karna hai (below). Ye order hamesha `pending` + `unpaid` banta hai.
- **Theme**: `frontend/src/styles.css` ke top par `:root` colors/fonts apni website ke mutabiq change karein.

### Website order example (customer site / QR page)
```js
await fetch('/api/orders', {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    clientKey: crypto.randomUUID(),            // create once per checkout; prevents duplicate orders on retry
    type: 'dine-in',                           // 'dine-in' | 'takeaway' | 'delivery'
    table: '<tableObjectId>',                  // required for dine-in
    customer: { name: 'Ali', phone: '03001234567', address: '...(delivery only)' },
    items: [{ menuItem: '<menuItemId>', quantity: 2 }] // NO prices: server uses DB prices
  })
});
```

## 3. Roles and access (enforced in the BACKEND)

| Route group | Allowed role |
|---|---|
| `/api/staff/*` | admin only |
| `/api/cashier/*` | cashier only |
| `/api/kitchen/*`, `/api/waiter/*` | kitchen / waiter only (placeholders: `/ping`) |
| `/api/tables` GET | admin, cashier, waiter |
| `/api/menu` GET | public; POST/PATCH admin only |
| `POST /api/orders` | public (rate-limited), website orders only |

Frontend `ProtectedRoute` redirects wrong-role users to their own panel, but the real protection is `protect` + `authorize()` middleware (user is re-loaded from DB on every request).

## 4. Security / integrity decisions
- No public registration route exists. Only an admin can create accounts. Admin cannot demote/deactivate self, and the last active admin can't be removed.
- Password hashes are never returned (`toJSON` strips them). Deactivating a user, changing their role, or resetting their password bumps `tokenVersion`, so their existing sessions die immediately.
- Login: generic error message, constant-time-ish compare, rate limit (20/15 min per IP), httpOnly + SameSite=Lax cookie (`secure` in production), Origin check on state-changing requests, helmet.
- Order totals are computed **only on the server** from DB prices. Discount is capped by `MAX_DISCOUNT_PERCENT`.
- **Payment status is separate from fulfillment status.** Website orders start `pending` + `unpaid`. They become `paid` only via cashier "Receive cash" (atomic update, so double-click/two cashiers can't record payment twice).
- Duplicate orders: `clientKey` unique index; same key returns the same order.
- Status flow: `pending -> preparing -> ready -> completed`, cancel only from pending/preparing and only while unpaid (no refund feature). **Completing requires paid.**
- POS orders start as `preparing` (cashier accepted them by creating them).

## 5. Cashier pages
Login, Dashboard (real stats, auto-refresh), New Order/POS (search, categories, cart, takeaway/dine-in, tables, discount, tax, cash, receipt print), Online Website Orders (auto-refresh every 15s, accept/reject, status, cash), Dine-In Orders, All Orders, Order History (filters + reprint receipt), Profile (name + password change).

## 6. Manual acceptance checklist
1. Admin creates cashier/kitchen/waiter -> each logs in -> lands on `/cashier`, `/kitchen`, `/waiter`.
2. Kitchen user opens `/cashier` or `/admin` in the URL -> redirected back to `/kitchen`. `curl` to `/api/staff` with a cashier cookie -> 403.
3. POST a website order (example above) -> appears in Cashier > Online Orders as **pending / unpaid**; stays unpaid until "Receive cash".
4. POS: create takeaway with cash -> receipt prints; create dine-in unpaid -> shows in Dine-In -> receive cash -> complete.
5. Deactivate a logged-in cashier from admin -> their next request returns 401.

## 7. Not included (on purpose)
Kitchen/waiter functionality, refunds, card payments, table management UI (tables are seeded; `POST /api/tables` exists for admin), menu management UI (API exists: `POST/PATCH /api/menu`).
