import { Router } from 'express';
import { rateLimit } from '../middleware/security.js';
import asyncHandler from '../utils/asyncHandler.js';
import { createOrder } from '../services/orderService.js';

const router = Router();

/**
 * POST /api/orders   (no login: used by the customer website / QR ordering)
 * body: { type, table?, customer:{name,phone,address?,notes?}, items:[{menuItem, quantity}], clientKey }
 * Always created as status "pending" + paymentStatus "unpaid".
 */
router.post(
  '/',
  rateLimit({ windowMs: 10 * 60 * 1000, max: 30, message: 'Too many orders from this device, try again later.' }),
  asyncHandler(async (req, res) => {
    const { order, duplicate } = await createOrder({ source: 'online', body: req.body });
    res.status(duplicate ? 200 : 201).json({
      duplicate,
      order: { orderNumber: order.orderNumber, status: order.status, paymentStatus: order.paymentStatus, total: order.total },
    });
  })
);

export default router;
