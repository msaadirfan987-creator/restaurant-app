import { Router } from 'express';
import { protect, authorize } from '../middleware/auth.js';

export const kitchenRouter = Router();
kitchenRouter.use(protect, authorize('kitchen'));
kitchenRouter.get('/ping', (req, res) => res.json({ ok: true, panel: 'kitchen', user: req.user.name }));
// TODO (later): GET /orders (queue), PATCH /orders/:id/status ...

export const waiterRouter = Router();
waiterRouter.use(protect, authorize('waiter'));
waiterRouter.get('/ping', (req, res) => res.json({ ok: true, panel: 'waiter', user: req.user.name }));
// TODO (later): table service, order taking ...
