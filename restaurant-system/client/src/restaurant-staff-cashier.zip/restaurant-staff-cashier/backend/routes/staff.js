import { Router } from 'express';
import User, { ROLES } from '../models/User.js';
import { protect, authorize } from '../middleware/auth.js';
import asyncHandler from '../utils/asyncHandler.js';
import HttpError from '../utils/httpError.js';
import { escapeRegex, str, assertObjectId } from '../utils/helpers.js';

const router = Router();
router.use(protect, authorize('admin')); // every staff route is admin-only, enforced here on the server

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function validateNew({ name, email, password, role }) {
  if (name.length < 2) throw new HttpError(400, 'Name must be at least 2 characters');
  if (!EMAIL_RE.test(email)) throw new HttpError(400, 'A valid email is required');
  if (!ROLES.includes(role)) throw new HttpError(400, `Role must be one of: ${ROLES.join(', ')}`);
  if (typeof password !== 'string' || password.length < 8 || password.length > 72) {
    throw new HttpError(400, 'Password must be 8-72 characters');
  }
}

async function activeAdminCountExcluding(id) {
  return User.countDocuments({ role: 'admin', isActive: true, _id: { $ne: id } });
}

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const filter = {};
    const search = str(req.query.search, 80);
    if (search) {
      const rx = new RegExp(escapeRegex(search), 'i');
      filter.$or = [{ name: rx }, { email: rx }];
    }
    if (ROLES.includes(req.query.role)) filter.role = req.query.role;
    if (req.query.status === 'active') filter.isActive = true;
    if (req.query.status === 'inactive') filter.isActive = false;

    const staff = await User.find(filter).sort({ createdAt: -1 });
    res.json({ staff });
  })
);

router.post(
  '/',
  asyncHandler(async (req, res) => {
    const data = {
      name: str(req.body.name, 80),
      email: str(req.body.email, 120).toLowerCase(),
      password: req.body.password,
      role: req.body.role,
    };
    validateNew(data);
    if (await User.exists({ email: data.email })) throw new HttpError(409, 'A user with this email already exists');
    const user = await User.create(data); // password hashed by the model hook
    res.status(201).json({ user });
  })
);

router.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    assertObjectId(req.params.id);
    const user = await User.findById(req.params.id);
    if (!user) throw new HttpError(404, 'Staff member not found');

    if (req.body.name !== undefined) {
      const name = str(req.body.name, 80);
      if (name.length < 2) throw new HttpError(400, 'Name must be at least 2 characters');
      user.name = name;
    }
    if (req.body.email !== undefined) {
      const email = str(req.body.email, 120).toLowerCase();
      if (!EMAIL_RE.test(email)) throw new HttpError(400, 'A valid email is required');
      if (email !== user.email && (await User.exists({ email, _id: { $ne: user._id } }))) {
        throw new HttpError(409, 'A user with this email already exists');
      }
      user.email = email;
    }
    if (req.body.role !== undefined && req.body.role !== user.role) {
      if (!ROLES.includes(req.body.role)) throw new HttpError(400, 'Invalid role');
      if (String(user._id) === String(req.user._id)) throw new HttpError(400, 'You cannot change your own role');
      if (user.role === 'admin' && (await activeAdminCountExcluding(user._id)) === 0) {
        throw new HttpError(400, 'At least one active admin must remain');
      }
      user.role = req.body.role;
      user.tokenVersion += 1; // role change forces re-login
    }
    await user.save();
    res.json({ user });
  })
);

router.patch(
  '/:id/status',
  asyncHandler(async (req, res) => {
    assertObjectId(req.params.id);
    if (typeof req.body.isActive !== 'boolean') throw new HttpError(400, 'isActive (boolean) is required');
    const user = await User.findById(req.params.id);
    if (!user) throw new HttpError(404, 'Staff member not found');

    if (!req.body.isActive) {
      if (String(user._id) === String(req.user._id)) throw new HttpError(400, 'You cannot deactivate your own account');
      if (user.role === 'admin' && (await activeAdminCountExcluding(user._id)) === 0) {
        throw new HttpError(400, 'At least one active admin must remain');
      }
      user.tokenVersion += 1; // kicks out active sessions immediately
    }
    user.isActive = req.body.isActive;
    await user.save();
    res.json({ user });
  })
);

router.post(
  '/:id/reset-password',
  asyncHandler(async (req, res) => {
    assertObjectId(req.params.id);
    const { newPassword } = req.body;
    if (typeof newPassword !== 'string' || newPassword.length < 8 || newPassword.length > 72) {
      throw new HttpError(400, 'Password must be 8-72 characters');
    }
    const user = await User.findById(req.params.id).select('+password');
    if (!user) throw new HttpError(404, 'Staff member not found');
    user.password = newPassword;
    user.tokenVersion += 1; // all of that user's sessions end
    await user.save();
    res.json({ message: 'Password reset. Share the new password with the staff member securely.' });
  })
);

export default router;
