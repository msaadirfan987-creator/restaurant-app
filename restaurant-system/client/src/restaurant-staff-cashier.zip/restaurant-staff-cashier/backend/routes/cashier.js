import { Router } from 'express';
import Order, { ORDER_STATUSES, ORDER_TYPES } from '../models/Order.js';
import { protect, authorize } from '../middleware/auth.js';
import asyncHandler from '../utils/asyncHandler.js';
import HttpError from '../utils/httpError.js';
import { assertObjectId, escapeRegex, str, startOfToday } from '../utils/helpers.js';
import { createOrder, recordCashPayment, changeStatus } from '../services/orderService.js';

const router = Router();
router.use(protect, authorize('cashier')); // only cashiers; admin-only routes are never reachable from here

const populate = [
  { path: 'table', select: 'number seats' },
  { path: 'receivedBy', select: 'name' },
  { path: 'createdBy', select: 'name' },
];

router.get(
  '/stats',
  asyncHandler(async (_req, res) => {
    const today = startOfToday();
    const [ordersToday, cash, pending, completedToday, unpaidActive, onlinePending] = await Promise.all([
      Order.countDocuments({ createdAt: { $gte: today }, status: { $ne: 'cancelled' } }),
      Order.aggregate([
        { $match: { paymentStatus: 'paid', paidAt: { $gte: today } } },
        { $group: { _id: null, sum: { $sum: '$total' }, count: { $sum: 1 } } },
      ]),
      Order.countDocuments({ status: 'pending' }),
      Order.countDocuments({ status: 'completed', updatedAt: { $gte: today } }),
      Order.countDocuments({ paymentStatus: 'unpaid', status: { $nin: ['cancelled'] } }),
      Order.countDocuments({ source: 'online', status: 'pending' }),
    ]);
    res.json({
      ordersToday,
      cashSalesToday: cash[0]?.sum || 0,
      paymentsToday: cash[0]?.count || 0,
      pending,
      completedToday,
      unpaidActive,
      onlinePending,
    });
  })
);

router.get(
  '/orders',
  asyncHandler(async (req, res) => {
    const q = req.query;
    const filter = {};

    if (['online', 'pos'].includes(q.source)) filter.source = q.source;
    if (ORDER_TYPES.includes(q.type)) filter.type = q.type;
    if (['unpaid', 'paid'].includes(q.paymentStatus)) filter.paymentStatus = q.paymentStatus;

    if (q.group === 'active') filter.status = { $in: ['pending', 'preparing', 'ready'] };
    else if (q.group === 'past') filter.status = { $in: ['completed', 'cancelled'] };
    if (ORDER_STATUSES.includes(q.status)) filter.status = q.status;

    if (q.from || q.to) {
      filter.createdAt = {};
      if (q.from && !isNaN(new Date(q.from))) filter.createdAt.$gte = new Date(`${q.from}T00:00:00`);
      if (q.to && !isNaN(new Date(q.to))) filter.createdAt.$lte = new Date(`${q.to}T23:59:59.999`);
      if (!Object.keys(filter.createdAt).length) delete filter.createdAt;
    }

    const search = str(q.search, 60);
    if (search) {
      const rx = new RegExp(escapeRegex(search), 'i');
      filter.$or = [{ 'customer.name': rx }, { 'customer.phone': rx }];
      const n = Number(search.replace('#', ''));
      if (Number.isInteger(n)) filter.$or.push({ orderNumber: n });
    }

    const page = Math.max(1, parseInt(q.page) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(q.limit) || 20));
    const [orders, total] = await Promise.all([
      Order.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit).populate(populate),
      Order.countDocuments(filter),
    ]);
    res.json({ orders, total, page, pages: Math.max(1, Math.ceil(total / limit)) });
  })
);

router.get(
  '/orders/:id',
  asyncHandler(async (req, res) => {
    assertObjectId(req.params.id);
    const order = await Order.findById(req.params.id).populate(populate);
    if (!order) throw new HttpError(404, 'Order not found');
    res.json({ order });
  })
);

router.post(
  '/orders',
  asyncHandler(async (req, res) => {
    const { order, duplicate } = await createOrder({ source: 'pos', body: req.body, user: req.user });
    await order.populate(populate);
    res.status(duplicate ? 200 : 201).json({ order, duplicate });
  })
);

router.patch(
  '/orders/:id/status',
  asyncHandler(async (req, res) => {
    assertObjectId(req.params.id);
    const order = await changeStatus(req.params.id, req.body.status, req.body.reason);
    await order.populate(populate);
    res.json({ order });
  })
);

router.post(
  '/orders/:id/pay',
  asyncHandler(async (req, res) => {
    assertObjectId(req.params.id);
    const order = await recordCashPayment(req.params.id, req.body.amountReceived, req.user);
    await order.populate(populate);
    res.json({ order });
  })
);

export default router;
