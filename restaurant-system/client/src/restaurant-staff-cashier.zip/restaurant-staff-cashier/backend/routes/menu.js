import { Router } from 'express';
import MenuItem from '../models/MenuItem.js';
import { protect, authorize } from '../middleware/auth.js';
import asyncHandler from '../utils/asyncHandler.js';
import HttpError from '../utils/httpError.js';
import { assertObjectId, str } from '../utils/helpers.js';

const router = Router();

// Public: the website menu + POS both read from here (available items only)
router.get(
  '/',
  asyncHandler(async (_req, res) => {
    const items = await MenuItem.find({ isAvailable: true }).sort({ category: 1, name: 1 });
    res.json({ items });
  })
);

function pick(body) {
  const out = {};
  if (body.name !== undefined) out.name = str(body.name, 100);
  if (body.category !== undefined) out.category = str(body.category, 50);
  if (body.description !== undefined) out.description = str(body.description, 300);
  if (body.image !== undefined) out.image = str(body.image, 300);
  if (body.price !== undefined) {
    const p = Number(body.price);
    if (!Number.isFinite(p) || p < 0) throw new HttpError(400, 'Invalid price');
    out.price = p;
  }
  if (typeof body.isAvailable === 'boolean') out.isAvailable = body.isAvailable;
  return out;
}

router.post(
  '/',
  protect,
  authorize('admin'),
  asyncHandler(async (req, res) => res.status(201).json({ item: await MenuItem.create(pick(req.body)) }))
);

router.patch(
  '/:id',
  protect,
  authorize('admin'),
  asyncHandler(async (req, res) => {
    assertObjectId(req.params.id);
    const item = await MenuItem.findByIdAndUpdate(req.params.id, pick(req.body), { new: true, runValidators: true });
    if (!item) throw new HttpError(404, 'Menu item not found');
    res.json({ item });
  })
);

export default router;
