import { Router } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import { protect } from '../middleware/auth.js';
import { rateLimit } from '../middleware/security.js';
import asyncHandler from '../utils/asyncHandler.js';
import HttpError from '../utils/httpError.js';
import { config } from '../config/env.js';
import { str } from '../utils/helpers.js';

const router = Router();
const DUMMY_HASH = bcrypt.hashSync('dummy-password-for-timing', 12);

const cookieOptions = {
  httpOnly: true,
  sameSite: 'lax',
  secure: config.isProd,
  maxAge: 8 * 60 * 60 * 1000,
  path: '/',
};

const sign = (user) =>
  jwt.sign({ id: user._id, tv: user.tokenVersion }, process.env.JWT_SECRET, { expiresIn: config.jwtExpiresIn });

router.post(
  '/login',
  rateLimit({ windowMs: 15 * 60 * 1000, max: 20, message: 'Too many login attempts. Try again in 15 minutes.' }),
  asyncHandler(async (req, res) => {
    const email = str(req.body.email, 120).toLowerCase();
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    if (!email || !password) throw new HttpError(400, 'Email and password are required');

    const user = await User.findOne({ email }).select('+password');
    // always run bcrypt so response time doesn't reveal whether the email exists
    const ok = await bcrypt.compare(password, user ? user.password : DUMMY_HASH);
    if (!user || !ok) throw new HttpError(401, 'Invalid email or password');
    if (!user.isActive) throw new HttpError(403, 'This account has been deactivated. Contact the admin.');

    user.lastLoginAt = new Date();
    await user.save();
    res.cookie('token', sign(user), cookieOptions);
    res.json({ user });
  })
);

router.post('/logout', (_req, res) => {
  res.clearCookie('token', { ...cookieOptions, maxAge: undefined });
  res.json({ message: 'Logged out' });
});

router.get('/me', protect, (req, res) => res.json({ user: req.user }));

// Safe self-service changes only: name + password. Email and role can only be changed by an admin.
router.patch(
  '/profile',
  protect,
  asyncHandler(async (req, res) => {
    const name = str(req.body.name, 80);
    if (name.length < 2) throw new HttpError(400, 'Name must be at least 2 characters');
    req.user.name = name;
    await req.user.save();
    res.json({ user: req.user });
  })
);

router.patch(
  '/password',
  protect,
  asyncHandler(async (req, res) => {
    const { currentPassword, newPassword } = req.body;
    if (typeof currentPassword !== 'string' || typeof newPassword !== 'string') throw new HttpError(400, 'Both passwords are required');
    if (newPassword.length < 8 || newPassword.length > 72) throw new HttpError(400, 'New password must be 8-72 characters');

    const user = await User.findById(req.user._id).select('+password');
    if (!(await user.comparePassword(currentPassword))) throw new HttpError(400, 'Current password is incorrect');

    user.password = newPassword;
    user.tokenVersion += 1; // logs out every other session
    await user.save();
    res.cookie('token', sign(user), cookieOptions); // keep this session alive
    res.json({ message: 'Password updated' });
  })
);

export default router;
