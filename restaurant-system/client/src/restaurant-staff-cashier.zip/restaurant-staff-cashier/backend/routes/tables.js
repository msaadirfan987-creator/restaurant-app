import { Router } from 'express';
import Table from '../models/Table.js';
import Order from '../models/Order.js';
import { protect, authorize } from '../middleware/auth.js';
import asyncHandler from '../utils/asyncHandler.js';
import HttpError from '../utils/httpError.js';

const router = Router();

router.get(
  '/',
  protect,
  authorize('admin', 'cashier', 'waiter'),
  asyncHandler(async (_req, res) => {
    const tables = await Table.find({ isActive: true }).sort({ number: 1 }).lean();
    const busy = await Order.distinct('table', { type: 'dine-in', status: { $in: ['pending', 'preparing', 'ready'] } });
    const busySet = new Set(busy.map(String));
    res.json({ tables: tables.map((t) => ({ ...t, busy: busySet.has(String(t._id)) })) });
  })
);

router.post(
  '/',
  protect,
  authorize('admin'),
  asyncHandler(async (req, res) => {
    const number = Number(req.body.number);
    const seats = Number(req.body.seats) || 4;
    if (!Number.isInteger(number) || number < 1) throw new HttpError(400, 'Table number must be a positive integer');
    res.status(201).json({ table: await Table.create({ number, seats }) });
  })
);

export default router;
