import { config } from '../config/env.js';
import HttpError from '../utils/httpError.js';

// CSRF defence-in-depth (cookie is already SameSite=Lax):
// reject state-changing requests whose Origin header is present but not our frontend.
export const originCheck = (req, _res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.headers.origin;
  if (origin && origin !== config.clientUrl) return next(new HttpError(403, 'Origin not allowed'));
  next();
};

// Tiny in-memory rate limiter (use Redis-backed one if you run multiple instances)
export const rateLimit = ({ windowMs, max, message }) => {
  const hits = new Map();
  setInterval(() => {
    const now = Date.now();
    for (const [k, v] of hits) if (v.reset < now) hits.delete(k);
  }, windowMs).unref();

  return (req, _res, next) => {
    const key = req.ip;
    const now = Date.now();
    const rec = hits.get(key);
    if (!rec || rec.reset < now) {
      hits.set(key, { count: 1, reset: now + windowMs });
      return next();
    }
    rec.count += 1;
    if (rec.count > max) return next(new HttpError(429, message || 'Too many requests, try later'));
    next();
  };
};
