import mongoose from 'mongoose';

export const ORDER_TYPES = ['dine-in', 'takeaway', 'delivery'];
export const ORDER_STATUSES = ['pending', 'preparing', 'ready', 'completed', 'cancelled'];

const itemSchema = new mongoose.Schema(
  {
    menuItem: { type: mongoose.Schema.Types.ObjectId, ref: 'MenuItem', required: true },
    name: { type: String, required: true },
    price: { type: Number, required: true }, // price snapshot at order time
    quantity: { type: Number, required: true, min: 1 },
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema(
  {
    orderNumber: { type: Number, required: true, unique: true },
    clientKey: { type: String, unique: true, sparse: true }, // idempotency key
    source: { type: String, enum: ['online', 'pos'], required: true },
    type: { type: String, enum: ORDER_TYPES, required: true },
    table: { type: mongoose.Schema.Types.ObjectId, ref: 'Table' },
    customer: {
      name: { type: String, default: '' },
      phone: { type: String, default: '' },
      address: { type: String, default: '' },
      notes: { type: String, default: '' },
    },
    items: { type: [itemSchema], validate: (v) => v.length > 0 },
    subtotal: { type: Number, required: true },
    discountType: { type: String, enum: ['none', 'percent', 'amount'], default: 'none' },
    discountValue: { type: Number, default: 0 },
    discount: { type: Number, default: 0 },
    taxRate: { type: Number, default: 0 },
    tax: { type: Number, default: 0 },
    total: { type: Number, required: true },

    // fulfillment status and payment status are deliberately separate
    status: { type: String, enum: ORDER_STATUSES, default: 'pending' },
    cancelReason: { type: String, default: '' },
    paymentStatus: { type: String, enum: ['unpaid', 'paid'], default: 'unpaid' },
    paymentMethod: { type: String, enum: ['cash'], default: 'cash' },
    paidAt: Date,
    amountReceived: Number,
    changeGiven: Number,
    receivedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

orderSchema.index({ createdAt: -1 });
orderSchema.index({ status: 1, paymentStatus: 1 });
orderSchema.index({ source: 1, status: 1 });

export default mongoose.models.Order || mongoose.model('Order', orderSchema);
