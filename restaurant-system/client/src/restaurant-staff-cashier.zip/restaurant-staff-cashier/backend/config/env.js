import 'dotenv/config';
process.env.TZ = process.env.TZ || 'Asia/Karachi';

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error('FATAL: JWT_SECRET missing or shorter than 32 characters (see .env.example)');
  process.exit(1);
}
if (!process.env.MONGO_URI) {
  console.error('FATAL: MONGO_URI missing');
  process.exit(1);
}

export const config = {
  port: Number(process.env.PORT) || 5000,
  clientUrl: process.env.CLIENT_URL || 'http://localhost:5173',
  isProd: process.env.NODE_ENV === 'production',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '8h',
  restaurantName: process.env.RESTAURANT_NAME || 'My Restaurant',
  currency: process.env.CURRENCY || 'Rs',
  taxRate: Number(process.env.TAX_RATE ?? 0),
  maxDiscountPercent: Number(process.env.MAX_DISCOUNT_PERCENT ?? 20),
};
