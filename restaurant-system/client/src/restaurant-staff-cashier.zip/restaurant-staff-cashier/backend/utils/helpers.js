import mongoose from 'mongoose';
import HttpError from './httpError.js';

export const escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
export const r2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
export const str = (v, max = 200) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

export function assertObjectId(id, label = 'id') {
  if (!mongoose.isValidObjectId(id)) throw new HttpError(400, `Invalid ${label}`);
}

export function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}
