import mongoose from 'mongoose';
import MenuItem from '../models/MenuItem.js';
import Table from '../models/Table.js';
import Order, { ORDER_TYPES } from '../models/Order.js';
import { nextOrderNumber } from '../models/Counter.js';
import { config } from '../config/env.js';
import HttpError from '../utils/httpError.js';
import { r2, str } from '../utils/helpers.js';

export const TRANSITIONS = {
  pending: ['preparing', 'cancelled'],
  preparing: ['ready', 'cancelled'],
  ready: ['completed'],
  completed: [],
  cancelled: [],
};

// Build order lines from DB prices only. The client sends ids + quantities, never prices.
async function buildItems(rawItems) {
  if (!Array.isArray(rawItems) || rawItems.length === 0) throw new HttpError(400, 'Order must contain at least one item');
  if (rawItems.length > 60) throw new HttpError(400, 'Too many items in one order');

  const merged = new Map();
  for (const it of rawItems) {
    const qty = Number(it?.quantity);
    if (!mongoose.isValidObjectId(it?.menuItem) || !Number.isInteger(qty) || qty < 1 || qty > 50) {
      throw new HttpError(400, 'Invalid item or quantity (1-50 allowed per item)');
    }
    const key = String(it.menuItem);
    merged.set(key, (merged.get(key) || 0) + qty);
  }

  const docs = await MenuItem.find({ _id: { $in: [...merged.keys()] } });
  const byId = new Map(docs.map((d) => [String(d._id), d]));
  const items = [];
  for (const [id, qty] of merged) {
    const d = byId.get(id);
    if (!d) throw new HttpError(400, 'One of the items no longer exists');
    if (!d.isAvailable) throw new HttpError(400, `"${d.name}" is currently unavailable`);
    if (qty > 50) throw new HttpError(400, `Quantity for "${d.name}" is too high`);
    items.push({ menuItem: d._id, name: d.name, price: d.price, quantity: qty });
  }
  return items;
}

export function computeTotals(items, discountType = 'none', discountValue = 0) {
  const subtotal = r2(items.reduce((s, i) => s + i.price * i.quantity, 0));
  let discount = 0;
  const value = Number(discountValue) || 0;

  if (discountType === 'percent' || discountType === 'amount') {
    if (value < 0) throw new HttpError(400, 'Discount cannot be negative');
    discount = discountType === 'percent' ? subtotal * (value / 100) : value;
    const cap = subtotal * (config.maxDiscountPercent / 100);
    if (discount > cap + 0.001) {
      throw new HttpError(400, `Discount exceeds the allowed maximum (${config.maxDiscountPercent}% of subtotal)`);
    }
    discount = r2(discount);
  } else if (discountType !== 'none') {
    throw new HttpError(400, 'Invalid discount type');
  }

  const taxable = subtotal - discount;
  const tax = r2(taxable * config.taxRate);
  const total = r2(taxable + tax);
  return { subtotal, discount, taxRate: config.taxRate, tax, total };
}

const PHONE_RE = /^[0-9+\-\s()]{7,20}$/;

function parseCustomer(body, { requireNamePhone, requireName, requireAddress }) {
  const c = body.customer || {};
  const customer = {
    name: str(c.name, 80),
    phone: str(c.phone, 20),
    address: str(c.address, 200),
    notes: str(c.notes, 200),
  };
  if ((requireNamePhone || requireName) && !customer.name) throw new HttpError(400, 'Customer name is required');
  if (requireNamePhone && !customer.phone) throw new HttpError(400, 'Customer phone is required');
  if (customer.phone && !PHONE_RE.test(customer.phone)) throw new HttpError(400, 'Invalid phone number');
  if (requireAddress && !customer.address) throw new HttpError(400, 'Delivery address is required');
  return customer;
}

/**
 * Shared creator for website orders (source 'online') and POS orders (source 'pos').
 * - totals computed here, from DB prices
 * - idempotent via clientKey (double click / retry returns the same order)
 */
export async function createOrder({ source, body, user = null }) {
  const isPos = source === 'pos';
  const type = body.type;
  const allowedTypes = isPos ? ['dine-in', 'takeaway'] : ORDER_TYPES;
  if (!allowedTypes.includes(type)) throw new HttpError(400, `Order type must be one of: ${allowedTypes.join(', ')}`);

  const clientKey = str(body.clientKey, 64);
  if (isPos && !clientKey) throw new HttpError(400, 'clientKey is required');
  if (clientKey) {
    const existing = await Order.findOne({ clientKey });
    if (existing) return { order: existing, duplicate: true };
  }

  const customer = parseCustomer(body, {
    requireNamePhone: !isPos && type !== 'dine-in',
    requireName: isPos && type === 'takeaway',
    requireAddress: !isPos && type === 'delivery',
  });

  let table;
  if (type === 'dine-in') {
    if (!mongoose.isValidObjectId(body.table)) throw new HttpError(400, 'Please select a table for dine-in');
    table = await Table.findOne({ _id: body.table, isActive: true });
    if (!table) throw new HttpError(400, 'Selected table does not exist');
  }

  const items = await buildItems(body.items);
  // discounts are a cashier privilege; website orders never get one
  const totals = isPos ? computeTotals(items, body.discountType || 'none', body.discountValue) : computeTotals(items);

  const doc = {
    orderNumber: await nextOrderNumber(),
    clientKey: clientKey || undefined,
    source,
    type,
    table: table?._id,
    customer,
    items,
    ...totals,
    discountType: isPos ? body.discountType || 'none' : 'none',
    discountValue: isPos ? Number(body.discountValue) || 0 : 0,
    status: isPos ? 'preparing' : 'pending',
    paymentStatus: 'unpaid',
    createdBy: user?._id,
  };

  // POS can take cash in the same step. Online orders are NEVER created as paid.
  if (isPos && body.payNow) {
    const received = Number(body.amountReceived);
    if (!Number.isFinite(received) || received < totals.total) {
      throw new HttpError(400, 'Amount received must be at least the order total');
    }
    Object.assign(doc, {
      paymentStatus: 'paid',
      paidAt: new Date(),
      amountReceived: r2(received),
      changeGiven: r2(received - totals.total),
      receivedBy: user._id,
    });
  }

  try {
    const order = await Order.create(doc);
    return { order, duplicate: false };
  } catch (e) {
    if (e.code === 11000 && clientKey) {
      const existing = await Order.findOne({ clientKey });
      if (existing) return { order: existing, duplicate: true };
    }
    throw e;
  }
}

// Atomic: the filter itself guarantees we only pay an unpaid, non-cancelled order once.
export async function recordCashPayment(orderId, amountReceived, user) {
  const order = await Order.findById(orderId);
  if (!order) throw new HttpError(404, 'Order not found');
  if (order.status === 'cancelled') throw new HttpError(409, 'Cannot take payment for a cancelled order');
  if (order.paymentStatus === 'paid') throw new HttpError(409, 'This order is already paid');

  const received = Number(amountReceived);
  if (!Number.isFinite(received) || received < order.total) {
    throw new HttpError(400, 'Amount received must be at least the order total');
  }

  const updated = await Order.findOneAndUpdate(
    { _id: orderId, paymentStatus: 'unpaid', status: { $ne: 'cancelled' } },
    {
      $set: {
        paymentStatus: 'paid',
        paidAt: new Date(),
        amountReceived: r2(received),
        changeGiven: r2(received - order.total),
        receivedBy: user._id,
      },
    },
    { new: true }
  );
  if (!updated) throw new HttpError(409, 'Payment was already recorded or order changed. Refresh and check.');
  return updated;
}

export async function changeStatus(orderId, nextStatus, reason = '') {
  const order = await Order.findById(orderId);
  if (!order) throw new HttpError(404, 'Order not found');

  const allowed = TRANSITIONS[order.status] || [];
  if (!allowed.includes(nextStatus)) {
    throw new HttpError(409, `Cannot move order from "${order.status}" to "${nextStatus}"`);
  }
  if (nextStatus === 'completed' && order.paymentStatus !== 'paid') {
    throw new HttpError(409, 'Receive cash payment before completing the order');
  }
  if (nextStatus === 'cancelled' && order.paymentStatus === 'paid') {
    throw new HttpError(409, 'A paid order cannot be cancelled (refunds are not supported)');
  }

  const set = { status: nextStatus };
  if (nextStatus === 'cancelled') set.cancelReason = str(reason, 200);

  // `status: order.status` in the filter prevents two cashiers racing on the same order
  const updated = await Order.findOneAndUpdate({ _id: orderId, status: order.status }, { $set: set }, { new: true });
  if (!updated) throw new HttpError(409, 'Order was changed by someone else. Refresh and try again.');
  return updated;
}
