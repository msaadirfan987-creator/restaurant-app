import './config/env.js';
import connectDB from './config/db.js';
import mongoose from 'mongoose';
import User from './models/User.js';
import MenuItem from './models/MenuItem.js';
import Table from './models/Table.js';

await connectDB();

// 1) first admin (only if no admin exists yet)
if (!(await User.exists({ role: 'admin' }))) {
  const { ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
  if (!ADMIN_EMAIL || !ADMIN_PASSWORD || ADMIN_PASSWORD.length < 8) {
    console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD (min 8 chars) in .env first');
    process.exit(1);
  }
  await User.create({ name: ADMIN_NAME || 'Admin', email: ADMIN_EMAIL.toLowerCase(), password: ADMIN_PASSWORD, role: 'admin' });
  console.log(`Admin created: ${ADMIN_EMAIL}  (change the password after first login)`);
} else console.log('Admin already exists - skipped');

// 2) starter menu + tables ONLY if the collections are empty. Replace with your real menu.
if ((await MenuItem.countDocuments()) === 0) {
  await MenuItem.insertMany([
    { name: 'Chicken Biryani', category: 'Mains', price: 450, description: 'Aromatic basmati rice with chicken' },
    { name: 'Beef Karahi (Half)', category: 'Mains', price: 1400 },
    { name: 'Chicken Tikka (2 pcs)', category: 'BBQ', price: 380 },
    { name: 'Seekh Kebab (4 pcs)', category: 'BBQ', price: 520 },
    { name: 'Garlic Naan', category: 'Breads', price: 70 },
    { name: 'Plain Naan', category: 'Breads', price: 50 },
    { name: 'Fresh Lime', category: 'Drinks', price: 150 },
    { name: 'Soft Drink', category: 'Drinks', price: 100 },
    { name: 'Gulab Jamun (2 pcs)', category: 'Desserts', price: 180 },
  ]);
  console.log('Starter menu inserted');
}
if ((await Table.countDocuments()) === 0) {
  await Table.insertMany(Array.from({ length: 10 }, (_, i) => ({ number: i + 1, seats: i < 6 ? 4 : 6 })));
  console.log('10 tables inserted');
}

await mongoose.disconnect();
