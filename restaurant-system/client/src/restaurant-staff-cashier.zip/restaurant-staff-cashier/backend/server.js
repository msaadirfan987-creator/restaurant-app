import { config } from './config/env.js'; // must be first (loads .env, validates secrets, sets TZ)
import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import connectDB from './config/db.js';
import { notFound, errorHandler } from './middleware/error.js';
import { originCheck } from './middleware/security.js';

import authRoutes from './routes/auth.js';
import staffRoutes from './routes/staff.js';
import menuRoutes from './routes/menu.js';
import tableRoutes from './routes/tables.js';
import publicOrderRoutes from './routes/publicOrders.js';
import cashierRoutes from './routes/cashier.js';
import { kitchenRouter, waiterRouter } from './routes/panels.js';

const app = express();
app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: config.clientUrl, credentials: true }));
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());
app.use(originCheck);

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.get('/api/config', (_req, res) =>
  res.json({
    restaurantName: config.restaurantName,
    currency: config.currency,
    taxRate: config.taxRate,
    maxDiscountPercent: config.maxDiscountPercent,
  })
);

app.use('/api/auth', authRoutes);
app.use('/api/staff', staffRoutes);
app.use('/api/menu', menuRoutes);
app.use('/api/tables', tableRoutes);
app.use('/api/orders', publicOrderRoutes);
app.use('/api/cashier', cashierRoutes);
app.use('/api/kitchen', kitchenRouter);
app.use('/api/waiter', waiterRouter);

app.use(notFound);
app.use(errorHandler);

connectDB()
  .then(() => app.listen(config.port, () => console.log(`API running on http://localhost:${config.port}`)))
  .catch((e) => {
    console.error('Failed to start:', e.message);
    process.exit(1);
  });
